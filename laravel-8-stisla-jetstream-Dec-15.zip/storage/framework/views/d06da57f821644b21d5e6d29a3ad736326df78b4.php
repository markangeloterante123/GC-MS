<?php if($sortField !== $field): ?>
    <i class="text-muted fas fa-sort"></i>
<?php elseif($sortAsc): ?>
    <i class="fas fa-sort-up"></i>
<?php else: ?>
    <i class="fas fa-sort-down"></i>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel-8-stisla-jetstream-Dec-15\resources\views/components/sort-icon.blade.php ENDPATH**/ ?>