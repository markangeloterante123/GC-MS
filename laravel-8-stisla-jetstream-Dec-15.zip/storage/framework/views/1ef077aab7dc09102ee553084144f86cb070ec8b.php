<?php
    $user = auth()->user();
?>

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header_content', null, []); ?> 
        <h2><?php echo e(__('Announcement')); ?></h2>

        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('user.info')); ?>">Profile</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('setting.options')); ?>">Setting</a></div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Announcement')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <section class="section">
        <div class="row mt-sm-4">

            <div class="col-12">
                <?php if(session('status_delete')): ?>
                    <h6 class="alert alert-danger"><?php echo e(session('status_delete')); ?></h6>
                <?php endif; ?>
            </div>
            <div class="<?php echo e($user->is_admin == 1 ? 'col-md-7':'col-12'); ?> col-12">
                    <div class="card">
                        <!-- Start here -->
                        <div class="card-header">
                            <h4> <h4><i class="fa fa-info-circle"></i> Company Announcement </h4></h4>
                        </div>
                        <div class="card-body">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $date1 = $info->created_at;
                                $date2 = \Carbon\Carbon::now();
                                $dateCon1 = Carbon\Carbon::parse($date1);
                                $dateCon2 = Carbon\Carbon::parse($date2);
                                $days = $dateCon1->diffInDays($dateCon2);
                            ?>
                            <?php if($days <= 3): ?>
                                <span class="btn btn-warning btn-notification"> <i class="fa fa-bell"></i> New</span>
                            <?php elseif($days <= 10): ?>
                                <span class="btn btn-info btn-notification"> <i class="fa fa-calendar"></i> <?php echo e($days); ?> days ago</span>
                            <?php endif; ?>
                            <div class="accordion md-accordion" id="accordionEx<?php echo e($info->id); ?>" role="tablist" aria-multiselectable="true">
                                <div class="card">
                                        <div class="card-header" role="tab" id="headingTree">
                                            <a data-toggle="collapse" data-parent="#accordionEx<?php echo e($info->id); ?>" href="#collapseRec<?php echo e($info->id); ?>" aria-expanded="true"
                                                        aria-controls="collapseRec<?php echo e($info->id); ?>">
                                            <h3 class="mb-0 " style="color:#02b075;">
                                            <?php echo e($info->memo_title); ?> <i class="fas fa-angle-down rotate-icon"></i>
                                            </h3>
                                            </a>
                                        </div>
                                        <div id="collapseRec<?php echo e($info->id); ?>" class="collapse" role="tabpanel" aria-labelledby="headingTree"
                                                    data-parent="#accordionEx<?php echo e($info->id); ?>">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="accordion-wrapper">
                                                        <button class="toggles" >
                                                            View Details  <i class="fas fa-plus icon"></i>
                                                        </button>
                                                    <div class="content">
                                                        <h3>Date Issued: <span><?php echo e(\Carbon\carbon::parse( $info->created_at )->format('F, j  Y')); ?></span></h3>
                                                        <h3>Author By: <span><?php echo e($info->author_by); ?></span> </h3>
                                                        
                                                        <h2 style="padding-top:30px;">Details</h2>
                                                        <?php echo $info->content; ?>


                                                    </div>
                                                </div>
                                            </div>
                                            <?php if($user->is_admin == 1): ?>
                                                <div class="card-footer footer-display text-right">
                                                    <div class="row">
                                                        <div class="col-6">
                                                            <form action="<?php echo e(url('/memo/delete/'.$info->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button class="btn-button-2">Delete</button>
                                                            </form>
                                                        </div>
                                                        <div class="col-6 btn-pad">
                                                            <a href="<?php echo e(url('/memo/edit/'.$info->id)); ?>" class="btn-button-2 ">Edit</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- end here -->
                    </div>
                <div class="card">
                    <div class="card-footer">
                        <div id="table_pagination" class="py-3">
                            <?php echo e($data->links()); ?>

                        </div>
                    </div>
                </div>
            </div>

            <?php if($user->is_admin == 1): ?>
                <div class="col-md-5 col-12">
                    <div class="card">
                            <?php if(session('status')): ?>
                                <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
                            <?php endif; ?>
                        <div class="card-header">
                            <h4><i class="fas fa-plus"></i> Post Memo</h4>
                        </div>

                        <form action="<?php echo e(url('/memo/add/'.$user->name)); ?>" method="post"  class="needs-validation" novalidate="">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="card-body"> 
                                <div class="row">

                                    <div class="form-group col-12">
                                        <input 
                                            type="text" 
                                            name="memo_title"
                                            id="memo_title"
                                            class="form-control" 
                                            required=""
                                        >
                                        <label>Title</label>
                                        <div class="invalid-feedback">
                                            Please fill in the Title
                                        </div>
                                    </div>

                                    
                                    <label class="label-comment">Content</label>
                                    <div class="form-group col-12">
                                        <textarea name="content" class="form-control" id="content-memo" cols="30" rows="10" required="">
                                        </textarea>
                                        
                                        <div class="invalid-feedback">
                                            Please fill in content
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="card-footer text-right">
                                <button class="btn-button-2">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
            
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel-8-stisla-jetstream-Dec-15\resources\views/pages/memo/memo.blade.php ENDPATH**/ ?>