<?php
$links = [
    [
        "href" => "dashboard",
        "text" => "Dashboard",
        "icon" => "fas fa-fire",
        "is_multi" => false,
        "access"=>"0",
    ],
    [
        "href" => [
            [
                "section_text" => "Profile",
                "icon"=>"fas fa-user-circle",
                "section_list" => [
                    ["href" => "user.info", "text" => "My Profile"],
                    ["href" => "update.account", "text" => "Update Profile"],
                    ["href" => "update.password", "text" => "Update Password"],
                    ["href" => "update.setting", "text" => "Update Settings"],
                ]
            ]
        ],
        "access"=>"0",
        "text" => "Account Information",
        "is_multi" => true,
    ],
    [
        "href" => [
            [
                
                "section_text" => "User",
                "icon"=>"fas fa-user-plus",
                "section_list" => [
                    ["href" => "user", "text" => "Data User"],
                    ["href" => "user.new", "text" => "Add User"]
                ]
            ],
            [
                "section_text" => "Setting",
                "icon"=>"fas fa-cogs",
                "section_list" => [
                    ["href" => "setting.options", "text" => "Add Options"],
                ]
            ]
        ],
        "access"=>"1",
        "text" => "User",
        "is_multi" => true,
    ],    
];
$user = auth()->user();
$navigation_links = array_to_object($links);
?>


<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="<?php echo e(route('dashboard')); ?>">
                <img class="d-inline-block" width="32px" height="30.61px" src="" alt="">
            </a>
        </div>
        <?php $__currentLoopData = $navigation_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul class="sidebar-menu">
        <?php if($user->is_admin >= $link->access): ?>
            <li class="menu-header"><?php echo e($link->text); ?></li>
            <?php if(!$link->is_multi): ?>
            <li class="<?php echo e(Request::routeIs($link->href) ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route($link->href)); ?>"><i class="<?php echo e($link->icon); ?>"></i><span><?php echo e($link->text); ?></span></a>
            </li>
            <?php else: ?>
                <?php $__currentLoopData = $link->href; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $routes = collect($section->section_list)->map(function ($child) {
                        return Request::routeIs($child->href);
                    })->toArray();
                        $is_active = in_array(true, $routes);
                    ?>
                    <li class="dropdown <?php echo e(($is_active) ? 'active' : ''); ?>">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="<?php echo e($section->icon); ?>"></i> <span><?php echo e($section->section_text); ?></span></a>
                            <ul class="dropdown-menu">
                                <?php $__currentLoopData = $section->section_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="<?php echo e(Request::routeIs($child->href) ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route($child->href)); ?>">   <?php echo e($child->text); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endif; ?>    
        </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </aside>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-8-stisla-jetstream-Dec-15\resources\views/components/sidebar.blade.php ENDPATH**/ ?>