<?php
    $user = auth()->user();
?>

        <section class="section ">
          <div class="">
            <div class="row mt-sm-4">
              <div class="col-12 col-md-12 col-lg-5">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card profile-widget">
                  <div class="profile-widget-header">
                    <img src="<?php echo e(asset($info->profile_photo_url)); ?>" alt="<?php echo e($info->name); ?>" style="width:130px; height:130px;" class="rounded-circle profile-widget-picture">
                    <div class="profile-widget-items">
                      <div class="profile-widget-item">
                        <div class="profile-widget-item-label">Date Hired</div>
                        <div class="profile-widget-item-value"><?php echo e(\Carbon\Carbon::parse($info->date_hired)->format('j F, Y')); ?></div>
                      </div>
                      <div class="profile-widget-item">
                        <div class="profile-widget-item-label">Use Email</div>
                        <div class="profile-widget-item-value"><?php echo e($info->email); ?></div>
                      </div>
                    </div>
                  </div>
                  <div class="profile-widget-description">
                    <div class="profile-widget-name">
                        <?php echo e($info->name); ?> 
                        <div class="text-muted d-inline font-weight-normal">
                            <div class="slash"></div> 
                            <?php echo e($info->position); ?>

                        </div>    
                    </div>

                    Ujang maman is a superhero name in <b>Indonesia</b>, especially in my family. He is not a fictional character but an original hero in my family, a hero for his children and for his wife. So, I use the name as a user in this template. Not a tribute, I'm just bored with <b>'John Doe'</b>.
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- User Salary Informations -->
                <div class="card">
                  <div class="card-header">
                    <h4><i class="fa fa-history"></i> Salary History </h4>
                  </div>
                  <div class="card-body">
                    <div class="row">
                      <!--Accordion wrapper-->
                        <div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
                          
                              <div class="card">
                                  <div class="card-header" role="tab" id="headingOne1">
                                    <a data-toggle="collapse" data-parent="#accordionEx" href="#collapseOne1" aria-expanded="true"
                                      aria-controls="collapseOne1">
                                      <h5 class="mb-0">
                                        Salary<i class="fas fa-angle-down rotate-icon"></i>
                                      </h5>
                                    </a>
                                  </div>
                                  <div id="collapseOne1" class="collapse show" role="tabpanel" aria-labelledby="headingOne1"
                                    data-parent="#accordionEx">
                                    <div class="card-body">
                                      <div class="row">
                                        <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $his): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($his->user_id == $userId): ?>
                                            <?php if($his->status == 1): ?>
                                              <div class="form-group option-container col-md-6 col-6">
                                                <label><?php echo e($his->type); ?></label>
                                                <input type="text" name="options" id="options" class="form-control form-holder" value="₱ <?php echo e(number_format($his->salary, 2)); ?>" disabled >
                                              
                                                <form action="<?php echo e(url('setting/salary/edit/'.$his->id)); ?>" method="POST">
                                                  <?php echo csrf_field(); ?>
                                                  <?php echo method_field('PUT'); ?>
                                                  <button type="submit" class="btn-dl-3 tool remove-option"> <i class="fa fa-16px fa-times text-red-500"></i>
                                                      <span class="tooltiptext  bg-danger">Update</span>
                                                  </button>
                                                </form>
                                              </div>
                                            <?php endif; ?>
                                          <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                      </div>
                                    </div>
                                  </div>
                              </div>
                              
                              <div class="card">
                                <div class="card-header" role="tab" id="headingTwo2">
                                  <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx" href="#collapseTwo2"
                                    aria-expanded="false" aria-controls="collapseTwo2">
                                    <h5 class="mb-0">
                                      History<i class="fas fa-angle-down rotate-icon"></i>
                                    </h5>
                                  </a>
                                </div>
                                <div id="collapseTwo2" class="collapse" role="tabpanel" aria-labelledby="headingTwo2"
                                  data-parent="#accordionEx">
                                  <div class="card-body">
                                    <div class="row">
                                        <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $his): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($his->user_id == $userId): ?>
                                            <?php if($his->status == 0): ?>
                                              <div class="form-group option-container col-md-6 col-6">
                                                <label><?php echo e($his->type); ?></label>
                                                <input type="text" name="options" id="options" class="form-control form-holder" value="₱ <?php echo e(number_format($his->salary, 2)); ?>" disabled >
                                              
                                                <form action="<?php echo e(url('setting/salary/edit/'.$his->id)); ?>" method="POST">
                                                  <?php echo csrf_field(); ?>
                                                  <?php echo method_field('PUT'); ?>
                                                  <button type="submit" class="btn-dl-3 tool remove-option"> <i class="fa fa-16px fa-times text-red-500"></i>
                                                      <span class="tooltiptext  bg-danger">Update</span>
                                                  </button>
                                                </form>
                                              </div>
                                            <?php endif; ?>
                                          <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </div>
                                  </div>
                                </div>
                              </div>
                        </div>
                      
                        <!-- End Accordion  -->

                    </div>
                  </div>
                  <?php if($user->is_admin == 1): ?>
                    <div class="card-header">
                        <h4><i class="fa fa-plus-circle"></i> Add Employee Salary</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(url('setting/salary/update/'.$userId)); ?>" id="form" method="post" class="needs-validation" novalidate="" >
                              <?php echo method_field('PUT'); ?>
                              <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-md-6 col-12">
                                  <label>Salary</label>
                                    <input 
                                        type="text" 
                                        name="salary" 
                                        id="salary" 
                                        class="form-control"
                                        required=""
                                    >
                                    <div class="invalid-feedback">
                                        Please fill in the Salary
                                    </div>
                                </div>

                                <div class="form-group col-md-6 col-12">
                                  <label>Type</label>
                                    <select name="type" id="type" class="form-control">
                                      <?php $__currentLoopData = $opt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($op->type == 3): ?>
                                          <option value="<?php echo e($op->options); ?>"><?php echo e($op->options); ?></option>
                                        <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <div class="invalid-feedback">
                                        Please Select Salary Type
                                    </div>
                                </div>

                                <div class="form-group col-md-12 col-12">
                                  <label>Effective Date</label>
                                    <textarea name="notes" id="notes" class="form-control" cols="30" rows="10" >
                                    </textarea>
                                    <div class="invalid-feedback">
                                        Please Select Salary Type
                                    </div>
                                </div>

                                <div class="form-group col-md-6 col-12">
                                  <label>Effective Date</label>
                                    <input 
                                        type="date" 
                                        name="effective_date" 
                                        id="effective_date" 
                                        class="form-control"
                                        required=""
                                    >
                                    <div class="invalid-feedback">
                                        Please Select Salary Type
                                    </div>
                                </div>

                                <div class="form-group col-md-6 col-12">
                                  <label>End Date</label>
                                    <input 
                                        type="date" 
                                        name="end_date" 
                                        id="end_date" 
                                        class="form-control"
                                        required=""
                                    >
                                    <div class="invalid-feedback">
                                        Please Select Salary Type
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer text-right">
                              <button class="btn btn-primary">Add Salary</button>
                            </div>
                        </form>
                    </div>
                  <?php endif; ?>

                  
                </div>
                <!-- Salary Div End here -->

              </div>
              
              
              <!-- Another Row -->
              <div class="col-12 col-md-12 col-lg-7">
                <div class="card">
                <?php if(session('status')): ?>
                    <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
                <?php endif; ?>

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <?php if($info->file == 0): ?>
                      <h6 class="alert alert-danger">No 201 File Record</h6>
                  <?php endif; ?> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <form action="<?php echo e(url('update/user/info/'.$userId)); ?>" method="post" class="needs-validation" novalidate="">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                      <div class="card-header">
                        <h4><i class="fa fa-archive"></i> Personal  </h4>
                      </div>
                      <div class="card-body">
                          <div class="row">
                            <div class="form-group col-md-5 col-12">
                              <label>First Name</label>
                              <input 
                                type="text" 
                                name="first_name" 
                                id="first_name" 
                                class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->first_name); ?>" 
                                required=""
                              >
                              <!-- || $info->update_request == 0 -->
                              <div class="invalid-feedback">
                                Please fill in the first name
                              </div>
                            </div>
                          
                            <div class="form-group col-md-4 col-12">
                              <label>Last Name</label>
                              <input 
                                type="text"
                                name="last_name"
                                id="last_name"
                                class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->last_name); ?>"
                                required=""
                              >
                              <div class="invalid-feedback">
                                Please fill in the last name
                              </div>
                            </div>
                            <div class="form-group col-md-3 col-12">
                              <label>Middle Name</label>
                              <input 
                                type="text" 
                                name="middle_name"
                                id="middle_name"
                                class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->middle_name); ?>" 
                              >
                              <div class="invalid-feedback">
                                Please fill in the Middle name
                              </div>
                            </div>
                          </div>
                          
                          <div class="row">
                            <div class="form-group col-md-6 col-12">
                              <label>Birthday</label>

                              <?php if($user->is_admin == 1): ?>
                                <input 
                                  type="date" 
                                  name="birthday" 
                                  id="birthday" 
                                  class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                  value="<?php echo e(Carbon\Carbon::parse($info->birthday)->format('Y-m-d')); ?>" 
                                >
                              <?php else: ?>
                                <input 
                                  type="text" 
                                  class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                  value="<?php echo e(Carbon\Carbon::parse($info->birthday)->format('F d, Y')); ?>" 
                                >
                              <?php endif; ?>

                              <div class="invalid-feedback">
                                Please fill in the Birthday
                              </div>
                            </div>                   
                            <div class="form-group col-md-6 col-12">
                              <label>Gender</label>
                                <?php if($user->is_admin == 1): ?>
                                  <select name="gender" id="gender" class="form-control " >
                                    <?php if(empty($info->gender )): ?>
                                      <option value="<?php echo e($info->gender); ?>">Select Gender</option>
                                      <option value="Female">Female</option>
                                    <?php else: ?>
                                      <option value="<?php echo e($info->gender); ?>"><?php echo e($info->gender); ?></option>
                                    <?php endif; ?>
                                    <?php if($info->gender == "Male"): ?>
                                      <option value="Female">Female</option>
                                    <?php else: ?>
                                      <option value="Male">Male</option>
                                    <?php endif; ?>                                
                                  </select>
                                <?php else: ?>
                                  <input 
                                    type="text" 
                                    class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                    value="<?php echo e($info->gender); ?>" 
                                  >
                                <?php endif; ?>

                              <div class="invalid-feedback">
                                Please Select in the Gender
                              </div>
                            </div>
                          </div>
                      </div>

                      <div class="card-header">
                        <h4><i class="fa fa-folder-open"></i> Employee Record</h4>
                      </div>
                      <div class="card-body">
                          <div class="row">
                            <div class="form-group col-md-6 col-12">
                              <label>Position</label>
                              <?php if($user->is_admin == 1): ?>
                                <select name="position" id="position" class="form-control">
                                    <option value="<?php echo e($info->position); ?>"><?php echo e($info->position); ?></option>
                                    <?php $__currentLoopData = $opt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($op->options != $info->position && $op->type == 2): ?>
                                        <option value="<?php echo e($op->options); ?>"><?php echo e($op->options); ?></option>
                                      <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="invalid-feedback">
                                  Please fill in the Employee Position
                                </div>
                              <?php else: ?>
                                <input 
                                  type="text"
                                  class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                  value="<?php echo e($info->position); ?>"
                                >
                              <?php endif; ?>
                            </div>                   
                            <div class="form-group col-md-6 col-12">
                              <label>Employment Status</label>
                              <?php if($user->is_admin == 1): ?>
                                <select name="employement_status" id="employement_status" class="form-control">
                                    <option value="<?php echo e($info->position); ?>"><?php echo e($info->employement_status); ?></option>
                                    <?php $__currentLoopData = $opt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($op->options != $info->employement_status && $op->type == 1): ?>
                                        <option value="<?php echo e($op->options); ?>"><?php echo e($op->options); ?></option>
                                      <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="invalid-feedback">
                                  Please select employee status
                                </div>
                              <?php else: ?>
                                <input 
                                  type="text"
                                  class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                  value="<?php echo e($info->employement_status); ?>" 
                                >
                              <?php endif; ?>
                            </div>
                          </div>

                          <div class="row">
                            <div class="form-group col-md-6 col-12">
                              <label>Date Hired</label>
                              <?php if($user->is_admin == 1): ?>
                                <input 
                                  type="date" 
                                  name="date_hired" 
                                  id="date_hired" 
                                  class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                  value="<?php echo e(Carbon\Carbon::parse($info->date_hired)->format('Y-m-d')); ?>" 
                                  required=""
                                >
                              <?php else: ?> 
                                <input 
                                  type="text"
                                  class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                  value="<?php echo e(Carbon\Carbon::parse($info->date_hired)->format('F m, Y')); ?>" 
                                >
                              <?php endif; ?>

                              <div class="invalid-feedback">
                                Please fill in the Date Hired
                              </div>
                            </div>                   
                            <div class="form-group col-md-6 col-12">
                              <label>End Contract Date</label>
                              <?php if($user->is_admin == 1): ?>
                                <input 
                                  type="date" 
                                  name="date_end"
                                  id="date_end"
                                  class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                  value="<?php echo e(Carbon\Carbon::parse($info->date_end)->format('Y-m-d')); ?>" 
                                  required=""
                                >
                              <?php else: ?> 
                                <input 
                                  type="text"
                                  class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                  value="<?php echo e(Carbon\Carbon::parse($info->date_end)->format('F m, Y')); ?>" 
                                >
                              <?php endif; ?>

                              <div class="invalid-feedback">
                                Please fill in the Status
                              </div>
                            </div>
                          </div>

                          <div class="row">
                            <div class="form-group col-12">
                              <label>Payslip</label>
                              <input 
                                type="text" 
                                name="pay_slip_link" 
                                id="pay_slip_link" 
                                class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->pay_slip_link); ?>" 
                                required=""
                              >
                              <div class="invalid-feedback">
                                Please fill in the Payslip URL
                              </div>
                            </div>
                          </div>
                      </div>
                    <?php if($user->is_admin == 1 || $info->update_request == 1): ?>
                      <div class="card-header">
                        <h4><i class="fa fa-phone"></i> Employee Contact</h4>
                      </div>
                      <div class="card-body">
                          <div class="row">
                            <div class="form-group col-md-6 col-12">
                              <label>Personal Email</label>
                              <input 
                                type="text" 
                                name="email" 
                                id="email" 
                                class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->email); ?>" 
                                required=""
                              >
                              <div class="invalid-feedback">
                                Please fill in the Personal Email
                              </div>
                            </div>                   
                            <div class="form-group col-md-6 col-12">
                              <label>Company Email</label>
                              <input 
                                type="text"
                                name="work_email"
                                id="work_email" 
                                class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->work_email); ?>" 
                                required=""
                              >
                              <div class="invalid-feedback">
                                Please fill in the Company Email
                              </div>
                            </div>
                          </div>

                          <div class="row">
                            <div class="form-group col-md-6 col-12">
                              <label>Phone No</label>
                              <input 
                                type="text" 
                                name="phone_no" 
                                id="phone_no" 
                                class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->phone_no); ?>" 
                                required=""
                              >
                              <div class="invalid-feedback">
                                Please fill in the Phone No
                              </div>
                            </div>                   
                            <div class="form-group col-md-6 col-12">
                              <label>Cellphone No</label>
                              <input 
                                type="text" 
                                name="cel_no"
                                id="cel_no"
                                class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->cel_no); ?>" 
                                required=""
                              >
                              <div class="invalid-feedback">
                                Please fill in the Cellphone No
                              </div>
                            </div>
                            <div class="form-group col-12">
                              <label>Current Address</label>
                              <input 
                                type="text" 
                                name="address_1"
                                id="address_1"
                                class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->address_1); ?>" 
                                required=""
                              >
                              <div class="invalid-feedback">
                                Please fill in the Current Address
                              </div>
                            </div>
                            <div class="form-group col-12">
                              <label>Address</label>
                              <input 
                                type="text" 
                                name="address_2"
                                id="address_2"
                                class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->address_2); ?>" 
                                required=""
                              >
                              <div class="invalid-feedback">
                                Please fill in the Address
                              </div>
                            </div>
                          </div>
                      </div>
                      <div class="card-header">
                        <h4><i class="fa fa-warning"></i> Incased of Emergency</h4>
                      </div>
                      <div class="card-body">
                        <div class="row">
                          <div class="form-group col-md-6 col-12">
                              <label>Name</label>
                              <input 
                                type="text" 
                                name="emergency_name"
                                id="emergency_name"
                                class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->emergency_name); ?>" 
                                required=""
                              >
                              <div class="invalid-feedback">
                                Please fill in the Name
                              </div>
                          </div>
                          <div class="form-group col-md-6 col-12">
                              <label>Relation</label>
                              <input 
                                type="text" 
                                name="emergency_relation"
                                id="emergency_relation"
                                class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->emergency_relation); ?>" 
                                required=""
                              >
                              <div class="invalid-feedback">
                                Please fill in the Name
                              </div>
                          </div>
                          <div class="form-group col-md-6 col-12">
                              <label>Emergency Contact</label>
                              <input 
                                type="text" 
                                name="emergency_contact"
                                id="emergency_contact"
                                class="form-control <?php echo e($user->is_admin == 1 || $info->update_request == 0 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->emergency_contact); ?>" 
                                required=""
                              >
                              <div class="invalid-feedback">
                                Please fill in the Name
                              </div>
                          </div>
                        </div>
                      </div>
                      <?php endif; ?>

                    
                    <?php if(  $user->is_admin == 1 || $info->update_request == 1): ?>
                      <div class="card-footer text-right">
                        <button class="btn btn-primary">Save Changes</button>
                      </div>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>

        <?php if($user->is_admin == 1): ?>
          <script defer>
              [...document.querySelectorAll(".input-disable")].forEach((element) => {
                  element.classList.toggle('input-able')
              });
          </script>
        <?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel-8-stisla-jetstream-Dec-15\resources\views/components/profile-information.blade.php ENDPATH**/ ?>