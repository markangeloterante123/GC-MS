<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>GCMS</title>
        <link rel="shortcut icon" href="<?php echo e(asset('img/logo-1.png')); ?>">

        <?php if(isset($meta)): ?>
            <?php echo e($meta); ?>

        <?php endif; ?>

        <!-- Styles -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans&family=Nunito:wght@400;600;700&family=Open+Sans&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/tailwind.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('stisla/css/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('stisla/css/components.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('vendor/notyf/notyf.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

        <link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free-v4-shims.min.css" media="all">
        <link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free-v4-font-face.min.css" media="all">
        <link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free.min.css" media="all">
        
        <!-- Editor -->	
        <script src="https://cdn.ckeditor.com/ckeditor5/23.0.0/classic/ckeditor.js"></script>

        <?php echo \Livewire\Livewire::styles(); ?>


        <!-- Scripts -->
        <script defer src="<?php echo e(asset('vendor/alpine.js')); ?>"></script>
    </head>
    <body class="antialiased">
        <div id="app">
            <div class="main-wrapper">
                <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Main Content -->
                <div class="main-content">
                    <section class="section">
                      <div class="section-header">
                        <?php if(isset($header_content)): ?>
                            <?php echo e($header_content); ?>

                        <?php else: ?>
                            <?php echo e(__('Profile Information')); ?>

                        <?php endif; ?>
                      </div>

                      <div class="section-body">
                        <?php echo e($slot); ?>

                      </div>
                    </section>
                  </div>
            </div>
        </div>

        <?php echo $__env->yieldPushContent('modals'); ?>

        <div class="modal fade" tabindex="-1" role="dialog" id="uploadCSVUser">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title">Import Records</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <?php if(Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <?php echo e(Session::get('success')); ?>

                    </div>

                    <?php elseif(Session::has('failed')): ?>
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <?php echo e(Session::get('success')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <div class="form-groups">
                            <label for="file">Choose File</label>
                            <input type="file" name="file" class="form-control" required="" accept="csv,xlsx">
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-whitesmoke br">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Upload Records</button>
                </div>
              </form>
            </div>
          </div>
        </div>

        <!-- General JS Scripts -->
        <script src="<?php echo e(asset('stisla/js/modules/jquery.min.js')); ?>"></script>
        <script defer async src="<?php echo e(asset('stisla/js/modules/popper.js')); ?>"></script>
        <script defer async src="<?php echo e(asset('stisla/js/modules/tooltip.js')); ?>"></script>
        <script src="<?php echo e(asset('stisla/js/modules/bootstrap.min.js')); ?>"></script>
        <script defer src="<?php echo e(asset('stisla/js/modules/jquery.nicescroll.min.js')); ?>"></script>
        <script defer src="<?php echo e(asset('stisla/js/modules/moment.min.js')); ?>"></script>
        <script defer src="<?php echo e(asset('stisla/js/modules/marked.min.js')); ?>"></script>
        <script defer src="<?php echo e(asset('vendor/notyf/notyf.min.js')); ?>"></script>
        <script defer src="<?php echo e(asset('vendor/sweetalert/sweetalert.min.js')); ?>"></script>
        <script defer src="<?php echo e(asset('stisla/js/modules/chart.min.js')); ?>"></script>
        <script defer src="<?php echo e(asset('vendor/select2/select2.min.js')); ?>"></script>
        

        <script src="<?php echo e(asset('stisla/js/stisla.js')); ?>"></script>
        <script src="<?php echo e(asset('stisla/js/scripts.js')); ?>"></script>
        <!-- Modal Assets -->
        <script src="<?php echo e(asset('stisla/js/page/bootstrap-modal.js')); ?>"></script>

        <?php echo \Livewire\Livewire::scripts(); ?>


        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/main.js')); ?>"></script>
        <?php if(isset($script)): ?>
            <?php echo e($script); ?>

        <?php endif; ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-8-stisla-jetstream-Dec-15\resources\views/layouts/app.blade.php ENDPATH**/ ?>