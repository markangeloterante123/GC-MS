<?php return array (
  'client-data' => 'App\\Http\\Livewire\\ClientData',
  'create-user' => 'App\\Http\\Livewire\\CreateUser',
  'file.data-table' => 'App\\Http\\Livewire\\File\\DataTable',
  'table.main' => 'App\\Http\\Livewire\\Table\\Main',
);