ClassicEditor
    .create( document.querySelector( '#notes' ) )
    .catch( error => {
} );

ClassicEditor
    .create( document.querySelector( '#description-form' ) )
    .catch( error => {
} );

ClassicEditor
    .create( document.querySelector( '#description-form2' ) )
    .catch( error => {
} );

ClassicEditor
    .create( document.querySelector( '#description-form3' ) )
    .catch( error => {
} );

ClassicEditor
    .create( document.querySelector( '#description-form4' ) )
    .catch( error => {
} );

ClassicEditor
    .create( document.querySelector( '#details_reprimand' ) )
    .catch( error => {
} );


ClassicEditor
    .create( document.querySelector( '#no_of_offense_reprimand' ) )
    .catch( error => {
} );

ClassicEditor
    .create( document.querySelector( '#no_of_offense-edit' ) )
    .catch( error => {
} );

ClassicEditor
    .create( document.querySelector( '#details-edit' ) )
    .catch( error => {
} );

ClassicEditor
    .create( document.querySelector( '#details-edit-1' ) )
    .catch( error => {
} );

ClassicEditor
    .create( document.querySelector( '#no_of_offense-edit-2' ) )
    .catch( error => {
} );

ClassicEditor
    .create( document.querySelector( '#content-memo' ) )
    .catch( error => {
} );


ClassicEditor
    .create( document.querySelector( '#actions_taken-send' ) )
    .catch( error => {
} );


ClassicEditor
    .create( document.querySelector( '#content-edit-memo' ) )
    .catch( error => {
} );

ClassicEditor
    .create( document.querySelector( '#content-edit-memo2' ) )
    .catch( error => {
} );

ClassicEditor
    .create( document.querySelector( '#description-form6' ) )
    .catch( error => {
} );