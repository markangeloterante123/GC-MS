<?php

namespace App\Http\Livewire\File;

use Livewire\Component;

class DataTable extends Component
{
    public function render()
    {
        return view('livewire.file.data-table');
    }
}
