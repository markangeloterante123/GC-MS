<?php
    $user = auth()->user();
?>

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header_content', null, []); ?> 
        <h2><?php echo e(__('Repremands Records')); ?></h2>

        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('user.info')); ?>">Profile</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('setting.options')); ?>">Setting</a></div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Repremands Records')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <section class="section">
        <div class="row mt-sm-4">
            <div class="col-md-6 col-12">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h1>Active Repremand Records</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card">
                        <?php $__currentLoopData = $active; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-body">  
                                    <?php
                                        $date1 = $info->date_given;
                                        $date2 = \Carbon\Carbon::now();
                                        $dateCon1 = Carbon\Carbon::parse($date1);
                                        $dateCon2 = Carbon\Carbon::parse($date2);
                                        $days = $dateCon1->diffInDays($dateCon2);
                                    ?>
                                    <span class="btn  <?php echo e($days > 2 ? 'btn-danger':'btn-warning'); ?> btn-notification"> <i class="fa fa-calendar"></i>
                                        <?php if($days == 0): ?>
                                            New
                                        <?php else: ?>
                                            <?php echo e($days); ?> days ago
                                        <?php endif; ?>
                                    </span>
                                    <div class="card">
                                        <div class="card-header ">
                                            <h4>Employee Name: <?php echo e($info->name); ?></h4>
                                        </div>
                                        <div class="card-body">
                                            <h3 class="padding-top:30px;">Click here to <a href="<?php echo e(url('send/reprimand/'.$info->user_id)); ?>">View Details</a></h3>
                                        </div>
                                    </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>      
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-12">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h1>Submitted Written Reports</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card">
                            <?php $__currentLoopData = $answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card-body">
                                    <?php
                                        $date1 = $info->explanation_date;
                                        $date2 = \Carbon\Carbon::now();
                                        $dateCon1 = Carbon\Carbon::parse($date1);
                                        $dateCon2 = Carbon\Carbon::parse($date2);
                                        $days = $dateCon1->diffInDays($dateCon2);
                                    ?>
                                    <span class="btn  <?php echo e($days > 2 ? 'btn-info':'btn-success'); ?> btn-notification"> <i class="fa fa-bell-o"></i>
                                        <?php if($days == 0): ?>
                                            Recently Submitted
                                        <?php else: ?>
                                            <?php echo e($days); ?> days ago
                                        <?php endif; ?>
                                    </span>
                                    <div class="card">      
                                        <div class="card-header ">
                                            <h4><?php echo e($info->name); ?></h4>
                                        </div>
                                        <div class="card-body">
                                            <h3 class="padding-top:30px;">Click here to <a href="<?php echo e(url('send/reprimand/'.$info->user_id)); ?>">View Details</a></h3>
                                        </div>
                                    </div>     
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel-8-stisla-jetstream-Dec-15\resources\views/pages/reprimand/reprimands_records.blade.php ENDPATH**/ ?>