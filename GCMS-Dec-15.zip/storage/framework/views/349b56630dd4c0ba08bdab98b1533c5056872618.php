<?php
    $userAcc = auth()->user();
?>

<div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.data-table','data' => ['data' => $data,'model' => $users]]); ?>
<?php $component->withName('data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($users)]); ?>
         <?php $__env->slot('head', null, []); ?> 
            <tr>
                <th><a wire:click.prevent="sortBy('id')" role="button" href="#">
                    ID
                    <?php echo $__env->make('components.sort-icon', ['field' => 'id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </a></th>
                <th><a wire:click.prevent="sortBy('name')" role="button" href="#">
                    Name
                    <?php echo $__env->make('components.sort-icon', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </a></th>
                <th><a wire:click.prevent="sortBy('email')" role="button" href="#">
                    Email
                    <?php echo $__env->make('components.sort-icon', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </a></th>
                <th><a wire:click.prevent="sortBy('position')" role="button" href="#">
                    Position
                    <?php echo $__env->make('components.sort-icon', ['field' => 'position'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </a></th>
                <th><a wire:click.prevent="sortBy('employement_status')" role="button" href="#">
                    Employement Status
                    <?php echo $__env->make('components.sort-icon', ['field' => 'employement_status'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </a></th>
                <th>Action</th>
            </tr>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('body', null, []); ?> 
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr x-data="window.__controller.dataTableController(<?php echo e($user->id); ?>)">
                    <?php if($userAcc->id != $user->id): ?>
                    <td><?php echo e($user->id); ?></td>
                    <td class="userInformationTable">
                        <a href="<?php echo e(url('user/information/'.$user->id)); ?>">
                            <img src="<?php echo e(asset($user->profile_photo_url)); ?>" alt="<?php echo e($user->name); ?>"class="mr-3 rounded-circle" style="width:40px; height:40px;">
                        </a> 
                        <?php echo e($user->name); ?>

                    </td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->position); ?></td>
                    <td><?php echo e($user->employement_status); ?></td>
                    <td class="whitespace-no-wrap row-action--icon">
                        <?php if( $user->file == 0): ?>
                            <a role="button" href="<?php echo e(url('user/information/'.$user->id)); ?>" class="mr-3 tool"><i class="fa fa-16px fa-pen text-red-500"></i> 
                                <span class="tooltiptext bg-warning">No File Record</span>
                            </a>     
                        <?php else: ?> 
                            <a role="button" href="<?php echo e(url('user/information/'.$user->id)); ?>" class="mr-3 tool"><i class="fa fa-16px fa-pen text-green-500"></i>
                                <span class="tooltiptext bg-success">Edit File Record</span>
                            </a>
                        <?php endif; ?>
                        
                        <a role="button" href="<?php echo e(url('/send/reprimand/'.$user->id)); ?>" class="mr-3 tool"><i class="fa fa-16px  fa-file-text text-blue-500"></i>
                            <span class="tooltiptext bg-warning">Send Reprimand</span>
                        </a>
                        <?php if($user->is_admin == 0): ?>
                            <a role="button" x-on:click.prevent="deleteItem" href="#" class="mr-3 tool"><i class="fa fa-16px fa-trash text-red-500"></i>
                                <span class="tooltiptext bg-danger">Delete Account</span>
                            </a>
                        <?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-8-stisla-jetstream-Dec-15\resources\views/livewire/table/user.blade.php ENDPATH**/ ?>