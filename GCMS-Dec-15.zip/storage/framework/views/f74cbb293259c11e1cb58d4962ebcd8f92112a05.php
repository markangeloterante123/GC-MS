<?php
    $user = auth()->user();
?>

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
     <?php $__env->slot('header_content', null, []); ?> 
        <h1><?php echo e(__('Absences Records')); ?></h1>

        <div class="section-header-breadcrumb">
        <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('user')); ?>">User</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('tirediness.records')); ?>">Absences Records</a></div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Absences')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <section class="section">
        <div class="row mt-sm-4">

            
            <div class="<?php echo e($user->is_admin == 1 ? 'col-md-9':'col-12'); ?> col-12">
                <div class="card">
                    <div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
                         <div class="card">
                            <div class="card-header" role="tab" id="headingTree">
                                <a data-toggle="collapse" data-parent="#accordionEx" href="#collapseRec" aria-expanded="true" aria-controls="collapseRec">
                                    <h3 class="mb-0 " style="color:#02b075;">
                                        Year <?php echo e(\Carbon\Carbon::now()->format('Y')); ?> Absences Records <i class="fas fa-angle-down rotate-icon"></i>
                                    </h3>
                                </a>
                            </div>
                            <div id="collapseRec" class="collapse" role="tabpanel" aria-labelledby="headingTree" data-parent="#accordionEx">
                                <div class="card-body">
                                    <div class="row">
                                        
                                        <div class="accordion-wrapper">
                                            <button class="toggles" >
                                                    Month of January  <i class="fas fa-plus icon"></i>
                                            </button>
                                                <div class="content">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-striped text-sm text-gray-600">
                                                            <thead>
                                                                <tr>
                                                                    <th>Entry ID:</th>
                                                                    <th>Date</th>
                                                                    <th>Employee ID</th>
                                                                    <th>Last Name</th>
                                                                    <th>First Name</th>
                                                                    <th>Reason</th>
                                                                    <th>Day</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($record->year == \Carbon\Carbon::now()->format('Y') ): ?>
                                                                        <?php if($record->month == 'January'): ?>   
                                                                            <tr>
                                                                                <td><?php echo e($record->entryId); ?></td>
                                                                                <td>Jan, <?php echo e($record->date); ?></td>
                                                                                <td>
                                                                                    <?php if($record->employee_id <= 9): ?>
                                                                                        ID: 00<?php echo e($record->employee_id); ?>

                                                                                    <?php elseif($record->employee_id <= 99): ?>
                                                                                        ID: 0<?php echo e($record->employee_id); ?>

                                                                                    <?php else: ?>
                                                                                        ID: <?php echo e($record->employee_id); ?>

                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td><?php echo e($record->last_name); ?></td>
                                                                                <td><?php echo e($record->first_name); ?></td>
                                                                                <td><?php echo e($record->reason); ?></td>
                                                                                <td><?php echo e($record->day); ?></td>
                                                                                <td><a href="<?php echo e(url('send/reprimand/'.$record->user_id)); ?>" class="btn btn-warning " style="border-radius:50px"><i class="fas fa-arrow-right"></i> </a></td>
                                                                            </tr>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                            </div>
                                        </div>

                                        <div class="accordion-wrapper">
                                            <button class="toggles" >
                                                    Month of February  <i class="fas fa-plus icon"></i>
                                            </button>
                                                <div class="content">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-striped text-sm text-gray-600">
                                                            <thead>
                                                                <tr>
                                                                    <th>Entry ID:</th>
                                                                    <th>Date</th>
                                                                    <th>Employee ID</th>
                                                                    <th>Last Name</th>
                                                                    <th>First Name</th>
                                                                    <th>Reason</th>
                                                                    <th>Day</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($record->year == \Carbon\Carbon::now()->format('Y') ): ?>
                                                                        <?php if($record->month == 'February'): ?>   
                                                                            <tr>
                                                                                <td><?php echo e($record->entryId); ?></td>
                                                                                <td>Feb, <?php echo e($record->date); ?></td>
                                                                                <td>
                                                                                    <?php if($record->employee_id <= 9): ?>
                                                                                        ID: 00<?php echo e($record->employee_id); ?>

                                                                                    <?php elseif($record->employee_id <= 99): ?>
                                                                                        ID: 0<?php echo e($record->employee_id); ?>

                                                                                    <?php else: ?>
                                                                                        ID: <?php echo e($record->employee_id); ?>

                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td><?php echo e($record->last_name); ?></td>
                                                                                <td><?php echo e($record->first_name); ?></td>
                                                                                <td><?php echo e($record->reason); ?></td>
                                                                                <td><?php echo e($record->day); ?></td>
                                                                                <td><a href="<?php echo e(url('send/reprimand/'.$record->user_id)); ?>" class="btn btn-warning" style="border-radius:50px"><i class="fas fa-arrow-right"></i> </a></td>
                                                                            </tr>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                        </div>

                                        <div class="accordion-wrapper">
                                            <button class="toggles" >
                                                    Month of March  <i class="fas fa-plus icon"></i>
                                            </button>
                                                <div class="content">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-striped text-sm text-gray-600">
                                                            <thead>
                                                                <tr>
                                                                    <th>Entry ID:</th>
                                                                    <th>Date</th>
                                                                    <th>Employee ID</th>
                                                                    <th>Last Name</th>
                                                                    <th>First Name</th>
                                                                    <th>Reason</th>
                                                                    <th>Day</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($record->year == \Carbon\Carbon::now()->format('Y') ): ?>
                                                                        <?php if($record->month == 'March'): ?>   
                                                                            <tr>
                                                                                <td><?php echo e($record->entryId); ?></td>
                                                                                <td>Mar, <?php echo e($record->date); ?></td>
                                                                                <td>
                                                                                    <?php if($record->employee_id <= 9): ?>
                                                                                        ID: 00<?php echo e($record->employee_id); ?>

                                                                                    <?php elseif($record->employee_id <= 99): ?>
                                                                                        ID: 0<?php echo e($record->employee_id); ?>

                                                                                    <?php else: ?>
                                                                                        ID: <?php echo e($record->employee_id); ?>

                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td><?php echo e($record->last_name); ?></td>
                                                                                <td><?php echo e($record->first_name); ?></td>
                                                                                <td><?php echo e($record->reason); ?></td>
                                                                                <td><?php echo e($record->day); ?></td>
                                                                                <td><a href="<?php echo e(url('send/reprimand/'.$record->user_id)); ?>" class="btn btn-warning" style="border-radius:50px"><i class="fas fa-arrow-right"></i> </a></td>
                                                                            </tr>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                            </div>
                                        </div>

                                        <div class="accordion-wrapper">
                                            <button class="toggles" >
                                                    Month of April  <i class="fas fa-plus icon"></i>
                                            </button>
                                                <div class="content">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-striped text-sm text-gray-600">
                                                            <thead>
                                                                <tr>
                                                                    <th>Entry ID:</th>
                                                                    <th>Date</th>
                                                                    <th>Employee ID</th>
                                                                    <th>Last Name</th>
                                                                    <th>First Name</th>
                                                                    <th>Reason</th>
                                                                    <th>Day</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($record->year == \Carbon\Carbon::now()->format('Y') ): ?>
                                                                        <?php if($record->month == 'April'): ?>   
                                                                            <tr>
                                                                                <td><?php echo e($record->entryId); ?></td>
                                                                                <td>Apr, <?php echo e($record->date); ?></td>
                                                                                <td>
                                                                                    <?php if($record->employee_id <= 9): ?>
                                                                                        ID: 00<?php echo e($record->employee_id); ?>

                                                                                    <?php elseif($record->employee_id <= 99): ?>
                                                                                        ID: 0<?php echo e($record->employee_id); ?>

                                                                                    <?php else: ?>
                                                                                        ID: <?php echo e($record->employee_id); ?>

                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td><?php echo e($record->last_name); ?></td>
                                                                                <td><?php echo e($record->first_name); ?></td>
                                                                                <td><?php echo e($record->reason); ?></td>
                                                                                <td><?php echo e($record->day); ?></td>
                                                                                <td><a href="<?php echo e(url('send/reprimand/'.$record->user_id)); ?>" class="btn btn-warning" style="border-radius:50px"><i class="fas fa-arrow-right"></i> </a></td>
                                                                            </tr>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                            </div>
                                        </div>

                                        <div class="accordion-wrapper">
                                            <button class="toggles" >
                                                    Month of May  <i class="fas fa-plus icon"></i>
                                            </button>
                                                <div class="content">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-striped text-sm text-gray-600">
                                                            <thead>
                                                                <tr>
                                                                    <th>Entry ID:</th>
                                                                    <th>Date</th>
                                                                    <th>Employee ID</th>
                                                                    <th>Last Name</th>
                                                                    <th>First Name</th>
                                                                    <th>Reason</th>
                                                                    <th>Day</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($record->year == \Carbon\Carbon::now()->format('Y') ): ?>
                                                                        <?php if($record->month == 'May'): ?>   
                                                                            <tr>
                                                                                <td><?php echo e($record->entryId); ?></td>
                                                                                <td>May, <?php echo e($record->date); ?></td>
                                                                                <td>
                                                                                    <?php if($record->employee_id <= 9): ?>
                                                                                        ID: 00<?php echo e($record->employee_id); ?>

                                                                                    <?php elseif($record->employee_id <= 99): ?>
                                                                                        ID: 0<?php echo e($record->employee_id); ?>

                                                                                    <?php else: ?>
                                                                                        ID: <?php echo e($record->employee_id); ?>

                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td><?php echo e($record->last_name); ?></td>
                                                                                <td><?php echo e($record->first_name); ?></td>
                                                                                <td><?php echo e($record->reason); ?></td>
                                                                                <td><?php echo e($record->day); ?></td>
                                                                                <td><a href="<?php echo e(url('send/reprimand/'.$record->user_id)); ?>" class="btn btn-warning" style="border-radius:50px"><i class="fas fa-arrow-right"></i> </a></td>
                                                                            </tr>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                            </div>
                                        </div>

                                        <div class="accordion-wrapper">
                                            <button class="toggles" >
                                                    Month of June  <i class="fas fa-plus icon"></i>
                                            </button>
                                                <div class="content">                                                
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-striped text-sm text-gray-600">
                                                            <thead>
                                                                <tr>
                                                                    <th>Entry ID:</th>
                                                                    <th>Date</th>
                                                                    <th>Employee ID</th>
                                                                    <th>Last Name</th>
                                                                    <th>First Name</th>
                                                                    <th>Reason</th>
                                                                    <th>Day</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($record->year == \Carbon\Carbon::now()->format('Y') ): ?>
                                                                        <?php if($record->month == 'June'): ?>   
                                                                            <tr>
                                                                                <td><?php echo e($record->entryId); ?></td>
                                                                                <td>Jun, <?php echo e($record->date); ?></td>
                                                                                <td>
                                                                                    <?php if($record->employee_id <= 9): ?>
                                                                                        ID: 00<?php echo e($record->employee_id); ?>

                                                                                    <?php elseif($record->employee_id <= 99): ?>
                                                                                        ID: 0<?php echo e($record->employee_id); ?>

                                                                                    <?php else: ?>
                                                                                        ID: <?php echo e($record->employee_id); ?>

                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td><?php echo e($record->last_name); ?></td>
                                                                                <td><?php echo e($record->first_name); ?></td>
                                                                                <td><?php echo e($record->reason); ?></td>
                                                                                <td><?php echo e($record->day); ?></td>
                                                                                <td><a href="<?php echo e(url('send/reprimand/'.$record->user_id)); ?>" class="btn btn-warning" style="border-radius:50px"><i class="fas fa-arrow-right"></i> </a></td>
                                                                            </tr>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                            </div>
                                        </div>

                                        <div class="accordion-wrapper">
                                            <button class="toggles" >
                                                    Month of July  <i class="fas fa-plus icon"></i>
                                            </button>
                                                <div class="content">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-striped text-sm text-gray-600">
                                                            <thead>
                                                                <tr>
                                                                    <th>Entry ID:</th>
                                                                    <th>Date</th>
                                                                    <th>Employee ID</th>
                                                                    <th>Last Name</th>
                                                                    <th>First Name</th>
                                                                    <th>Reason</th>
                                                                    <th>Day</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($record->year == \Carbon\Carbon::now()->format('Y') ): ?>
                                                                        <?php if($record->month == 'July'): ?>   
                                                                            <tr>
                                                                                <td><?php echo e($record->entryId); ?></td>
                                                                                <td>Jul, <?php echo e($record->date); ?></td>
                                                                                <td>
                                                                                    <?php if($record->employee_id <= 9): ?>
                                                                                        ID: 00<?php echo e($record->employee_id); ?>

                                                                                    <?php elseif($record->employee_id <= 99): ?>
                                                                                        ID: 0<?php echo e($record->employee_id); ?>

                                                                                    <?php else: ?>
                                                                                        ID: <?php echo e($record->employee_id); ?>

                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td><?php echo e($record->last_name); ?></td>
                                                                                <td><?php echo e($record->first_name); ?></td>
                                                                                <td><?php echo e($record->reason); ?></td>
                                                                                <td><?php echo e($record->day); ?></td>
                                                                                <td><a href="<?php echo e(url('send/reprimand/'.$record->user_id)); ?>" class="btn btn-warning" style="border-radius:50px"><i class="fas fa-arrow-right"></i> </a></td>
                                                                            </tr>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                            </div>
                                        </div>

                                        <div class="accordion-wrapper">
                                            <button class="toggles" >
                                                    Month of August  <i class="fas fa-plus icon"></i>
                                            </button>
                                                <div class="content">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-striped text-sm text-gray-600">
                                                            <thead>
                                                                <tr>
                                                                    <th>Entry ID:</th>
                                                                    <th>Date</th>
                                                                    <th>Employee ID</th>
                                                                    <th>Last Name</th>
                                                                    <th>First Name</th>
                                                                    <th>Reason</th>
                                                                    <th>Day</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($record->year == \Carbon\Carbon::now()->format('Y') ): ?>
                                                                        <?php if($record->month == 'August'): ?>   
                                                                            <tr>
                                                                                <td><?php echo e($record->entryId); ?></td>
                                                                                <td>Aug, <?php echo e($record->date); ?></td>
                                                                                <td>
                                                                                    <?php if($record->employee_id <= 9): ?>
                                                                                        ID: 00<?php echo e($record->employee_id); ?>

                                                                                    <?php elseif($record->employee_id <= 99): ?>
                                                                                        ID: 0<?php echo e($record->employee_id); ?>

                                                                                    <?php else: ?>
                                                                                        ID: <?php echo e($record->employee_id); ?>

                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td><?php echo e($record->last_name); ?></td>
                                                                                <td><?php echo e($record->first_name); ?></td>
                                                                                <td><?php echo e($record->reason); ?></td>
                                                                                <td><?php echo e($record->day); ?></td>
                                                                                <td><a href="<?php echo e(url('send/reprimand/'.$record->user_id)); ?>" class="btn btn-warning" style="border-radius:50px"><i class="fas fa-arrow-right"></i> </a></td>
                                                                            </tr>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                            </div>
                                        </div>

                                        <div class="accordion-wrapper">
                                            <button class="toggles" >
                                                    Month of September  <i class="fas fa-plus icon"></i>
                                            </button>
                                                <div class="content">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-striped text-sm text-gray-600">
                                                            <thead>
                                                                <tr>
                                                                    <th>Entry ID:</th>
                                                                    <th>Date</th>
                                                                    <th>Employee ID</th>
                                                                    <th>Last Name</th>
                                                                    <th>First Name</th>
                                                                    <th>Reason</th>
                                                                    <th>Day</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($record->year == \Carbon\Carbon::now()->format('Y') ): ?>
                                                                        <?php if($record->month == 'September'): ?>   
                                                                            <tr>
                                                                                <td><?php echo e($record->entryId); ?></td>
                                                                                <td>Sep, <?php echo e($record->date); ?></td>
                                                                                <td>
                                                                                    <?php if($record->employee_id <= 9): ?>
                                                                                        ID: 00<?php echo e($record->employee_id); ?>

                                                                                    <?php elseif($record->employee_id <= 99): ?>
                                                                                        ID: 0<?php echo e($record->employee_id); ?>

                                                                                    <?php else: ?>
                                                                                        ID: <?php echo e($record->employee_id); ?>

                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td><?php echo e($record->last_name); ?></td>
                                                                                <td><?php echo e($record->first_name); ?></td>
                                                                                <td><?php echo e($record->reason); ?></td>
                                                                                <td><?php echo e($record->day); ?></td>
                                                                                <td><a href="<?php echo e(url('send/reprimand/'.$record->user_id)); ?>" class="btn btn-warning" style="border-radius:50px"><i class="fas fa-arrow-right"></i> </a></td>
                                                                            </tr>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                            </div>
                                        </div>

                                        <div class="accordion-wrapper">
                                            <button class="toggles" >
                                                    Month of October  <i class="fas fa-plus icon"></i>
                                            </button>
                                                <div class="content">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-striped text-sm text-gray-600">
                                                            <thead>
                                                                <tr>
                                                                    <th>Entry ID:</th>
                                                                    <th>Date</th>
                                                                    <th>Employee ID</th>
                                                                    <th>Last Name</th>
                                                                    <th>First Name</th>
                                                                    <th>Reason</th>
                                                                    <th>Day</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($record->year == \Carbon\Carbon::now()->format('Y') ): ?>
                                                                        <?php if($record->month == 'October'): ?>   
                                                                            <tr>
                                                                                <td><?php echo e($record->entryId); ?></td>
                                                                                <td>Oct, <?php echo e($record->date); ?></td>
                                                                                <td>
                                                                                    <?php if($record->employee_id <= 9): ?>
                                                                                        ID: 00<?php echo e($record->employee_id); ?>

                                                                                    <?php elseif($record->employee_id <= 99): ?>
                                                                                        ID: 0<?php echo e($record->employee_id); ?>

                                                                                    <?php else: ?>
                                                                                        ID: <?php echo e($record->employee_id); ?>

                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td><?php echo e($record->last_name); ?></td>
                                                                                <td><?php echo e($record->first_name); ?></td>
                                                                                <td><?php echo e($record->reason); ?></td>
                                                                                <td><?php echo e($record->day); ?></td>
                                                                                <td><a href="<?php echo e(url('send/reprimand/'.$record->user_id)); ?>" class="btn btn-warning" style="border-radius:50px"><i class="fas fa-arrow-right"></i> </a></td>
                                                                            </tr>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                            </div>
                                        </div>

                                        <div class="accordion-wrapper">
                                            <button class="toggles" >
                                                    Month of November  <i class="fas fa-plus icon"></i>
                                            </button>
                                                <div class="content">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-striped text-sm text-gray-600">
                                                            <thead>
                                                                <tr>
                                                                    <th>Entry ID:</th>
                                                                    <th>Date</th>
                                                                    <th>Employee ID</th>
                                                                    <th>Last Name</th>
                                                                    <th>First Name</th>
                                                                    <th>Reason</th>
                                                                    <th>Day</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($record->year == \Carbon\Carbon::now()->format('Y') ): ?>
                                                                        <?php if($record->month == 'November'): ?>   
                                                                            <tr>
                                                                                <td><?php echo e($record->entryId); ?></td>
                                                                                <td>Nov, <?php echo e($record->date); ?></td>
                                                                                <td>
                                                                                    <?php if($record->employee_id <= 9): ?>
                                                                                        ID: 00<?php echo e($record->employee_id); ?>

                                                                                    <?php elseif($record->employee_id <= 99): ?>
                                                                                        ID: 0<?php echo e($record->employee_id); ?>

                                                                                    <?php else: ?>
                                                                                        ID: <?php echo e($record->employee_id); ?>

                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td><?php echo e($record->last_name); ?></td>
                                                                                <td><?php echo e($record->first_name); ?></td>
                                                                                <td><?php echo e($record->reason); ?></td>
                                                                                <td><?php echo e($record->day); ?></td>
                                                                                <td><a href="<?php echo e(url('send/reprimand/'.$record->user_id)); ?>" class="btn btn-warning" style="border-radius:50px"><i class="fas fa-arrow-right"></i> </a></td>
                                                                            </tr>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                            </div>
                                        </div>

                                        <div class="accordion-wrapper">
                                            <button class="toggles" >
                                                    Month of December  <i class="fas fa-plus icon"></i>
                                            </button>
                                                <div class="content">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-striped text-sm text-gray-600">
                                                            <thead>
                                                                <tr>
                                                                    <th>Entry ID:</th>
                                                                    <th>Date</th>
                                                                    <th>Employee ID</th>
                                                                    <th>Last Name</th>
                                                                    <th>First Name</th>
                                                                    <th>Reason</th>
                                                                    <th>Day</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($record->year == \Carbon\Carbon::now()->format('Y') ): ?>
                                                                        <?php if($record->month == 'December'): ?>   
                                                                            <tr>
                                                                                <td><?php echo e($record->entryId); ?></td>
                                                                                <td>Dec, <?php echo e($record->date); ?></td>
                                                                                <td>
                                                                                    <?php if($record->employee_id <= 9): ?>
                                                                                        ID: 00<?php echo e($record->employee_id); ?>

                                                                                    <?php elseif($record->employee_id <= 99): ?>
                                                                                        ID: 0<?php echo e($record->employee_id); ?>

                                                                                    <?php else: ?>
                                                                                        ID: <?php echo e($record->employee_id); ?>

                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td><?php echo e($record->last_name); ?></td>
                                                                                <td><?php echo e($record->first_name); ?></td>
                                                                                <td><?php echo e($record->reason); ?></td>
                                                                                <td><?php echo e($record->day); ?></td>
                                                                                <td><a href="<?php echo e(url('send/reprimand/'.$record->user_id)); ?>" class="btn btn-warning" style="border-radius:50px"><i class="fas fa-arrow-right"></i> </a></td>
                                                                            </tr>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                            </div>
                                        </div>
                                    
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h1><i class="fas fa-list"></i> Absences All Records</h1>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped text-sm text-gray-600" >
                                <thead>
                                    <tr>
                                        <th>Entry ID:</th>
                                        <th>Date</th>
                                        <th>Day</th>
                                        <th>Employee ID</th>
                                        <th>Last Name</th>
                                        <th>First Name</th>
                                        <th>Reason</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($record->entryId); ?></td>
                                            <td><?php echo e($record->month); ?> <?php echo e($record->date); ?>, <?php echo e($record->year); ?></td>
                                            <td><?php echo e($record->day); ?></td>
                                            <td>
                                                <?php if($record->employee_id <= 9): ?>
                                                   ID: 00<?php echo e($record->employee_id); ?>

                                                <?php elseif($record->employee_id <= 99): ?>
                                                   ID: 0<?php echo e($record->employee_id); ?>

                                                <?php else: ?>
                                                   ID: <?php echo e($record->employee_id); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($record->last_name); ?></td>
                                            <td><?php echo e($record->first_name); ?></td>
                                            <td><?php echo e($record->reason); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div id="table_pagination" class="py-3">
                            <?php echo e($history->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 col-12">
                <?php if(session('status')): ?>
                    <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header" style="display:flex;justify-content:space-around;">
                        <h4>Add Absences Record</h4>
                        <a data-toggle="modal" data-target="#uploadAbsences" class="btn btn-info" style="border-radius:50px;"><i class="fas fa-plus"></i> Upload</a>
                    </div>
                
                    <form action="<?php echo e(url('absences')); ?>" method="post"  class="needs-validation" novalidate="">
                        <?php echo method_field('POST'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="row">
                                <!-- first field -->
                                <div class="form-group col-12">
                                    <select name="user_id" id="user_id" class="form-control" required="">
                                        <option value=""></option>
                                      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <label>Employee Name</label>
                                    <div class="invalid-feedback">
                                        Please Select Employee Name
                                    </div>
                                </div>
                                <!-- second field -->
                                <div class="form-group  col-12">
                                    <select name="reason" id="reason" class="form-control" required="">
                                        <option value=""></option>
                                        <option value="Sick">Sick</option>
                                        <option value="Birthday">Birthday</option>
                                        <option value="Relative / Family Birthday">Relative / Family Birthday</option>
                                        <option value="Personal Problem">Personal Problem</option>
                                        <option value="Others">Others</option>
                                        <option value="N/A">N/A</option>
                                        <option value="Tardiness">Tardiness</option>
                                        <option value="Weather">Weather</option>
                                        <option value="Transportation">Transportation</option>
                                        <option value="Health">Health</option>
                                    </select>
                                    <label>Reason</label>
                                    <div class="invalid-feedback">
                                            Please fill in the Reason
                                    </div>
                                </div>
                                <!-- 3rd field -->
                                <div class="form-group  col-12">
                                    <input type="date" name="date" id="date" class="form-control" required="">
                                    <label>Date</label>
                                    <div class="invalid-feedback">
                                            Please fill in the Date
                                    </div>
                                </div>
                                <div class="form-group col-12">
                                    <select name="day_form" id="day_form" class="form-control" required="">
                                        <option value=""></option>
                                        <option value="Sunday">Sunday</option>
                                        <option value="Monday">Monday</option>
                                        <option value="Tuesday">Tuesday</option>
                                        <option value="Wednesday">Wednesday</option>
                                        <option value="Thursday">Thursday</option>
                                        <option value="Friday">Friday</option>
                                        <option value="Saturday">Saturday</option>
                                    </select>
                                    <label>Select Day</label>
                                    <div class="invalid-feedback">
                                            Please fill in the Day
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="card-footer text-right">
                            <button class="btn-button-2">Save</button>
                        </div>
                    </form>

                </div>
            </div>

        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel-8-stisla-jetstream-Dec-15\resources\views/pages/absences/absence.blade.php ENDPATH**/ ?>