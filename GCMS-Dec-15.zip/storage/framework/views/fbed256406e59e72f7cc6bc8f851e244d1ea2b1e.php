<?php
    $user = auth()->user();
?>

        <section class="section ">
          <div class="">
            <div class="row mt-sm-4">
              <div class="col-12 col-md-12 col-lg-5">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card profile-widget">
                  <div class="profile-widget-header">
                    <img src="<?php echo e(asset($info->profile_photo_url)); ?>" alt="<?php echo e($info->name); ?>" style="width:130px; height:130px; border:3px solid #fff;" class="rounded-circle profile-widget-picture">
                    <div class="profile-widget-items">
                      <div class="profile-widget-item">
                        <div class="profile-widget-item-label title-label">Date Hired</div>
                        <div class="profile-widget-item-value title-value"><?php echo e(\Carbon\Carbon::parse($info->date_hired)->format('j F, Y')); ?></div>
                      </div>
                      <div class="profile-widget-item">
                        <div class="profile-widget-item-label title-label">Status</div>
                        <div class="profile-widget-item-value title-value">
                            <?php echo e($info->employement_status); ?>

                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="profile-widget-description">
                    <div class="profile-widget-name title-value">
                        Name:
                        <div class="text-muted d-inline font-weight-normal ">
                            <div class="slash"></div> 
                            <?php echo e($info->name); ?>

                        </div>
                    </div>
                    <div class="profile-widget-name title-value">
                        Company Email:
                        <div class="text-muted d-inline font-weight-normal ">
                            <div class="slash"></div> 
                            <?php echo e($info->work_email); ?>

                        </div>
                    </div>
                    <div class="profile-widget-name title-value">
                        Status:
                        <div class="text-muted d-inline font-weight-normal ">
                            <div class="slash"></div> 
                            <?php echo e($info->employement_status); ?>

                        </div>
                    </div>
                    <div class="profile-widget-name title-value">
                      Position:
                        <div class="text-muted d-inline font-weight-normal ">
                            <div class="slash"></div> 
                            <?php echo e($info->position); ?>

                        </div>
                    </div>
                    
                    <div class="profile-info">
                      <h2>Name: <?php echo e($info->name); ?></h2>
                      <h3>Company Email: <?php echo e($info->work_email); ?></h3>
                      <h3>Status: <?php echo e($info->employement_status); ?></h3>
                      <h3>Position: <?php echo e($info->position); ?></h3>
                    </div>
                    <?php $__currentLoopData = $opt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                      <?php if($op->options == $info->designation): ?>
                        <div class="user-information">
                          <h2><?php echo e($info->designation); ?></h2>
                          <p><?php echo e($op->description); ?></p>
                        </div>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- reprimand records -->
                  <div class="card">
                    <div class="card-header">
                      <h4><i class="fa fa-times-circle "></i> Reprimand</h4>
                    </div>
                    <div class="card-body">
                      <div class="row">
                        
                        <div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
                          <div class="card">
                            <div class="card-header" role="tab" id="headingTree">
                                <a data-toggle="collapse" data-parent="#accordionEx" href="#collapseRec" aria-expanded="true"
                                              aria-controls="collapseRec">
                                <h5 class="mb-0 " style="color:#02b075;">
                                    Reprimand Records<i class="fas fa-angle-down rotate-icon"></i>
                                </h5>
                                </a>
                            </div>
                            <div id="collapseRec" class="collapse" role="tabpanel" aria-labelledby="headingTree"
                                          data-parent="#accordionEx">
                                <div class="card-body">
                                    <div class="row">
                                      <?php $__currentLoopData = $reprimand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="accordion-wrapper">
                                            <button class="toggles" >
                                              <?php echo e($repri->status); ?> ( <?php echo e($repri->type_of_offense); ?> )
                                              <i class="fas fa-plus icon"></i>
                                            </button>
                                            <div class="content">
                                              <h3>Date Issued: <span><?php echo e(Carbon\Carbon::parse($repri->date_given)->format('M. d, Y')); ?></span></h3>
                                              <h3>Offense: <span><?php echo e($repri->no_of_offense); ?></span></h3>
                                              <h3>Issued By: <span><?php echo e($repri->issue_by); ?></span> </h3>
                                              <span>Click the link to the</span>
                                              <a href="<?php echo e(url('send/reprimand/'.$user->id)); ?>"> View Details </a>
                                            </div>
                                        </div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>
                <!-- End here -->
                
               
                <!-- User Salary Informations -->
                <div class="card">
                  <div class="card-header">
                    <h4><i class="fa fa-history"></i> Salary Records </h4>
                  </div>
                  <div class="card-body">
                    <div class="row">
                      <!--Accordion wrapper-->
                        <div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
                          
                              <div class="card">
                                  <div class="card-header" role="tab" id="headingOne1">
                                    <a data-toggle="collapse" data-parent="#accordionEx" href="#collapseOne1" aria-expanded="true"
                                      aria-controls="collapseOne1">
                                      <h5 class="mb-0 " style="color:#02b075;">
                                        Salary<i class="fas fa-angle-down rotate-icon"></i>
                                      </h5>
                                    </a>
                                  </div>
                                  <div id="collapseOne1" class="collapse show" role="tabpanel" aria-labelledby="headingOne1"
                                    data-parent="#accordionEx">
                                    <div class="card-body">
                                      <div class="row">
                                        <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $his): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($his->user_id == $userId): ?>
                                            <?php if($his->status == 1): ?>
                                              <!-- accordion  -->
                                              <div class="accordion-wrapper">
                                                <button class="toggles" ><?php echo e($his->type); ?> - ₱ <?php echo e(number_format($his->salary, 2)); ?><i class="fas fa-plus icon"></i></button>
                                                <div class="content">
                                                  <h3>Salary: ₱ <?php echo e(number_format($his->salary, 2)); ?></h3>
                                                  <h3>Type: <?php echo e($his->type); ?></h3>
                                                  <h3>Effective Date:  <?php echo e(Carbon\Carbon::parse($his->effective_date)->format('M. d, Y')); ?></h3>

                                                  <span>Notes</span>
                                                  <p><?php echo $his->notes; ?></p>
                                                  
                                                  <?php if($user->is_admin == 1): ?>
                                                    <form action="<?php echo e(url('setting/salary/edit/'.$his->id)); ?>" method="POST">
                                                      <?php echo csrf_field(); ?>
                                                      <?php echo method_field('PUT'); ?>
                                                      <button type="submit" class="btn-button-2">Replace</button>
                                                    </form>
                                                  <?php endif; ?>
                                                </div>
                                              </div>
                                              
                                            <?php endif; ?>
                                          <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                      </div>
                                    </div>
                                  </div>
                              </div>
                              
                              <div class="card">
                                <div class="card-header" role="tab" id="headingTwo2">
                                  <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx" href="#collapseTwo2"
                                    aria-expanded="false" aria-controls="collapseTwo2">
                                    <h5 class="mb-0" style="color:#02b075;">
                                      History<i class="fas fa-angle-down rotate-icon"></i>
                                    </h5>
                                  </a>
                                </div>
                                <div id="collapseTwo2" class="collapse" role="tabpanel" aria-labelledby="headingTwo2"
                                  data-parent="#accordionEx">
                                  <div class="card-body">
                                    <div class="row">
                                        <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $his): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($his->user_id == $userId): ?>
                                            <?php if($his->status == 0): ?>
                                            <div class="accordion-wrapper">
                                                <button class="toggles" >
                                                  <?php echo e($his->type); ?>

                                                  - ₱ <?php echo e(number_format($his->salary, 2)); ?>

                                                  <i class="fas fa-plus icon"></i>
                                                </button>
                                                <div class="content">
                                                  <h3>Salary: ₱ <?php echo e(number_format($his->salary, 2)); ?></h3>
                                                  <h3>Type: <?php echo e($his->type); ?></h3>
                                                  <h3>Effective Date:  <?php echo e(Carbon\Carbon::parse($his->effective_date)->format('M. d, Y')); ?></h3>

                                                  <span>Notes</span>
                                                  <p><?php echo $his->notes; ?></p>
                                                </div>
                                              </div>
                                            <?php endif; ?>
                                          <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </div>
                                  </div>
                                </div>
                              </div>
                        </div>
                      
                        <!-- End Accordion  -->

                    </div>
                  </div>
                  <?php if($user->is_admin == 1): ?>
                    <div class="card-header">
                        <h4><i class="fa fa-plus-circle"></i> Add Employee Salary</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(url('setting/salary/update/'.$userId)); ?>" id="form" method="post" class="needs-validation" novalidate="" >
                              <?php echo method_field('PUT'); ?>
                              <?php echo csrf_field(); ?>
                            <div class="row">

                                <div class="form-group col-md-6 col-12">
                                    <input 
                                        type="text" 
                                        name="salary" 
                                        id="salary" 
                                        class="form-control"
                                        required=""
                                    >
                                    <label>Salary</label>

                                    <div class="invalid-feedback">
                                        Please fill in the Salary Info
                                    </div>
                                </div>

                                <div class="form-group col-md-6 col-12">
                                    <select name="type" id="type" class="form-control" required="">
                                      <?php $__currentLoopData = $opt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($op->type == 3): ?>
                                          <option value="<?php echo e($op->options); ?>"><?php echo e($op->options); ?></option>
                                        <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <label>Type</label>
                                    <div class="invalid-feedback">
                                        Please Select Type of Salary
                                    </div>
                                </div>

                                <label class="label-comment">Comments</label>
                                <div class="form-group col-md-12 col-12">  
                                    <textarea name="notes" id="notes" class="form-control" cols="30" rows="10" required="">
                                    </textarea>
                                    <div class="invalid-feedback">
                                        Please add comment
                                    </div>
                                </div>

                                <div class="form-group col-md-6 col-12">
                                  
                                    <input 
                                        type="date" 
                                        name="effective_date" 
                                        id="effective_date" 
                                        class="form-control"
                                        required=""
                                    >
                                    <label class="label-2">Effective Date</label>
                                    <div class="invalid-feedback">
                                        Please Fill Effective Date
                                    </div>
                                </div>

                                <div class="form-group col-md-6 col-12">
                                  
                                    <input 
                                        type="date" 
                                        name="end_date" 
                                        id="end_date" 
                                        class="form-control"
                                        required=""
                                    >
                                    <label class="label-2">End Date</label>
                                    <div class="invalid-feedback">
                                        Please Fill End Date
                                    </div>
                                </div>
                            </div>    
                      </div>
                      <div class="card-footer text-right">
                        <button class="btn-button-2">Add Salary</button>
                      </div>
                    </form>
                  <?php endif; ?>
                </div>
                <!-- Salary Div End here -->
              </div>
              <!-- Another Row -->
              <div class="col-12 col-md-12 col-lg-7">
                <div class="card <?php echo e($info->file == 0 ? 'border-warning':''); ?>">
                <?php if(session('status')): ?>
                    <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
                <?php endif; ?>
                
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <?php if($info->file == 0): ?>
                      <h6 class="alert alert-danger">No 201 File Record</h6>
                  <?php endif; ?> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <form action="<?php echo e(url('update/user/info/'.$userId)); ?>" method="post" class="needs-validation" novalidate="">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                      <div class="card-header">
                        <h4><i class="fa fa-archive"></i> Personal  </h4>
                      </div>
                      <div class="card-body">
                          <div class="row">
                            <div class="form-group col-md-5 col-12">
                              
                              <input 
                                type="text" 
                                name="first_name" 
                                id="first_name" 
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->first_name); ?>" 
                                required=""
                              >
                              <label>First Name</label>

                              <!-- || $info->update_request == 0 -->
                              <div class="invalid-feedback">
                                Please fill in the first name
                              </div>
                            </div>
                          
                            <div class="form-group col-md-4 col-12">
                              
                              <input 
                                type="text"
                                name="last_name"
                                id="last_name"
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->last_name); ?>"
                                required=""
                              >
                              <label>Last Name</label>
                              <div class="invalid-feedback">
                                Please fill in the last name
                              </div>
                            </div>
                            <div class="form-group col-md-3 col-12">
                              
                              <input 
                                type="text" 
                                name="middle_name"
                                id="middle_name"
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->middle_name); ?>" 
                              >
                              <label>Middle Name</label>
                              <div class="invalid-feedback">
                                Please fill in the Middle name
                              </div>
                            </div>
                          </div>
                          
                          <div class="row">
                            <div class="form-group col-md-3 col-12">
                              <?php if($user->is_admin == 1): ?>
                                <input 
                                  type="date" 
                                  name="birthday" 
                                  id="birthday" 
                                  class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                  value="<?php echo e(Carbon\Carbon::parse($info->birthday)->format('Y-m-d')); ?>" 
                                >
                              <?php else: ?>
                                <input 
                                  type="text" 
                                  class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                  value="<?php echo e(Carbon\Carbon::parse($info->birthday)->format('F d, Y')); ?>" 
                                >
                              <?php endif; ?>
                              <label>Birthday</label>
                              <div class="invalid-feedback">
                                Please fill in the Birthday
                              </div>
                            </div>    
                            <div class="form-group col-md-3 col-12">
                                  <?php if($user->is_admin == 1): ?>
                                    <input 
                                      type="text" 
                                      name="age" 
                                      id="age" 
                                      class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                      value="<?php echo e($info->age); ?>" 
                                      required=""
                                    >
                                  <?php else: ?>
                                    <input 
                                      type="text" 
                                      class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                      value="<?php echo e($info->age); ?>" 
                                    >
                                  <?php endif; ?>
                                <label>Age</label>
                                <div class="invalid-feedback">
                                  Please fill in the Age
                                </div>
                            </div>               
                            <div class="form-group col-md-3 col-12">
                                <?php if($user->is_admin == 1): ?>
                                  <select name="gender" id="gender" class="form-control " required="">
                                    <?php if(empty($info->gender )): ?>
                                      <option value=""></option>
                                      <option value="Female">Female</option>
                                    <?php else: ?>
                                      <option value="<?php echo e($info->gender); ?>"><?php echo e($info->gender); ?></option>
                                    <?php endif; ?>
                                    <?php if($info->gender == "Male"): ?>
                                      <option value="Female">Female</option>
                                    <?php else: ?>
                                      <option value="Male">Male</option>
                                    <?php endif; ?>                                
                                  </select>
                                <?php else: ?>
                                  <input 
                                    type="text" 
                                    class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                    value="<?php echo e($info->gender); ?>" 
                                  >
                                <?php endif; ?>
                                <label>Select Gender</label>
                              <div class="invalid-feedback">
                                Please Select in the Gender
                              </div>
                            </div>
                            <div class="form-group col-md-3 col-12">
                                  <?php if($user->is_admin == 1): ?>
                                    <select name="marital_status" id="marital_status" class="form-control" required="">
                                      <option value="<?php echo e($info->marital_status); ?>"><?php echo e($info->marital_status); ?></option>
                                      <option value="Single">Single</option>
                                      <option value="Married">Married</option>
                                      <option value="Widowed">Widowed</option>
                                      <option value="Separated">Separated</option>
                                      <option value="Devorced">Devorced</option>
                                    </select>
                                  <?php else: ?>
                                    <input 
                                      type="text" 
                                      class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                      value="<?php echo e($info->marital_status); ?>" 
                                    >
                                  <?php endif; ?>
                                <label>Civil Status</label>
                                <div class="invalid-feedback">
                                  Please fill in up Civil Status
                                </div>
                            </div>
                          </div>
                      </div>

                      <div class="card-header">
                        <h4><i class="fa fa-folder-open"></i> Employee Record</h4>
                      </div>
                      <div class="card-body">
                          <div class="row">
                            <!-- position -->
                          <div class="form-group col-md-4 col-12">
                              <?php if($user->is_admin == 1): ?>
                                <select name="position" id="position" class="form-control" required="">
                                    <option value="<?php echo e($info->position); ?>"><?php echo e($info->position); ?></option>
                                    <?php $__currentLoopData = $opt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($op->options != $info->position && $op->type == 6): ?>
                                        <option value="<?php echo e($op->options); ?>"><?php echo e($op->options); ?></option>
                                      <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label>Position</label>
                                <div class="invalid-feedback">
                                  Please fill in the Employee designation
                                </div>
                              <?php else: ?>
                                <?php if($info->designation): ?>  
                                    <input 
                                      type="text"
                                      class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                      value="<?php echo e($info->position); ?>"
                                    >
                                  <?php else: ?>
                                    <input 
                                      type="text"
                                      class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                      value="Need Update"
                                    >
                                <?php endif; ?>
                                <label>Position</label>
                              <?php endif; ?>
                              
                            </div>

                            <div class="form-group col-md-4 col-12">
                              <?php if($user->is_admin == 1): ?>
                                <select name="designation" id="designation" class="form-control" required="">
                                    <option value="<?php echo e($info->designation); ?>"><?php echo e($info->designation); ?></option>
                                    <?php $__currentLoopData = $opt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($op->options != $info->designation && $op->type == 4): ?>
                                        <option value="<?php echo e($op->options); ?>"><?php echo e($op->options); ?></option>
                                      <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label>Designation</label>
                                <div class="invalid-feedback">
                                  Please fill in the Employee designation
                                </div>
                              <?php else: ?>
                                <?php if($info->designation): ?>  
                                    <input 
                                      type="text"
                                      class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                      value="<?php echo e($info->designation); ?>"
                                    >
                                  <?php else: ?>
                                    <input 
                                      type="text"
                                      class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                      value="Need Update"
                                    >
                                <?php endif; ?>
                                <label>Position</label>
                              <?php endif; ?>
                              
                            </div>

                            <div class="form-group col-md-4 col-12">
                              <?php if($user->is_admin == 1): ?>
                                <select name="type_of_contract" id="type_of_contract" class="form-control" required="">
                                    <option value="<?php echo e($info->type_of_contract); ?>"><?php echo e($info->type_of_contract); ?></option>
                                    <?php $__currentLoopData = $opt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($op->options != $info->type_of_contract && $op->type == 5): ?>
                                        <option value="<?php echo e($op->options); ?>"><?php echo e($op->options); ?></option>
                                      <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label>Type of Contract</label>
                                <div class="invalid-feedback">
                                  Please fill in the Employee Type of Contracts
                                </div>
                              <?php else: ?>
                                <?php if($info->type_of_contract): ?>  
                                  <input 
                                    type="text"
                                    class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                    value="<?php echo e($info->type_of_contract); ?>"
                                  >
                                <?php else: ?>
                                  <input 
                                    type="text"
                                    class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                    value="Need Update"
                                  >
                                <?php endif; ?>
                                <label>Type of Contract</label>
                              <?php endif; ?>
                              
                            </div>  

                            <div class="form-group col-md-4 col-12">
                              
                              <?php if($user->is_admin == 1): ?>
                                <select name="contracts" id="contracts" class="form-control" required="">
                                    <option value="<?php echo e($info->contracts); ?>"><?php echo e($info->contracts); ?></option>
                                    <?php $__currentLoopData = $opt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($op->options != $info->contracts && $op->type == 2): ?>
                                        <option value="<?php echo e($op->options); ?>"><?php echo e($op->options); ?></option>
                                      <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label>Contracts</label>
                                <div class="invalid-feedback">
                                  Please fill in the Employee Contracts
                                </div>
                              <?php else: ?>
                                <?php if($info->contracts): ?>  
                                  <input 
                                    type="text"
                                    class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                    value="<?php echo e($info->contracts); ?>"
                                  >
                                <?php else: ?>
                                  <input 
                                    type="text"
                                    class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                    value="Need Update"
                                  >
                                <?php endif; ?>
                                <label>Contracts</label>
                              <?php endif; ?>
                              
                            </div>   
                            
                            <div class="form-group col-md-4 col-12">
                              
                              <?php if($user->is_admin == 1): ?>
                                <select name="employement_status" id="employement_status" class="form-control" required="">
                                    <option value="<?php echo e($info->employement_status); ?>"><?php echo e($info->employement_status); ?></option>
                                      <?php $__currentLoopData = $opt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($op->options != $info->employement_status && $op->type == 1): ?>
                                          <option value="<?php echo e($op->options); ?>"><?php echo e($op->options); ?></option>
                                        <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label>Employement Status</label>
                                <div class="invalid-feedback">
                                  Please select employement status
                                </div>
                              <?php else: ?>
                                <?php if($info->employement_status): ?>  
                                  <input 
                                    type="text"
                                    class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                    value="<?php echo e($info->employement_status); ?>" 
                                  >
                                <?php else: ?>
                                  <input 
                                    type="text"
                                    class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                    value="Need Update" 
                                  >
                                <?php endif; ?>
                                <label>Employement Status</label>
                              <?php endif; ?>
                            </div>
                          
                            
                            <div class="form-group col-md-4 col-12">
                              
                              <?php if($user->is_admin == 1): ?>
                                <select name="contract_status" id="contract_status" class="form-control" required="">
                                    <option value="<?php echo e($info->contract_status); ?>"><?php echo e($info->contract_status); ?></option>
                                    <option value="Active"> Active</option>
                                    <option value="Up for renewa"> Up for renewal</option>
                                    <option value="Not Renewed"> Not Renewed</option>
                                    <option value="Notice Served"> Notice Served</option>
                                    <option value="Expired"> Expired</option>
                                    <option value="Termindated"> Termindated</option>
                                </select>
                                <label>Contract Status</label>
                                <div class="invalid-feedback">
                                  Please select contract status
                                </div>
                              <?php else: ?>
                                <?php if($info->contract_status): ?>  
                                  <input 
                                    type="text"
                                    class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                    value="<?php echo e($info->contract_status); ?>" 
                                  >
                                <?php else: ?>
                                  <input 
                                    type="text"
                                    class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                    value="Need Update" 
                                  >
                                <?php endif; ?>
                                <label>Contract Status</label>
                              <?php endif; ?>
                            </div>
                          </div>

                          <div class="row">
                            <div class="form-group col-md-4 col-12">
                              
                              <?php if($user->is_admin == 1): ?>
                                <input 
                                  type="date" 
                                  name="date_hired" 
                                  id="date_hired" 
                                  class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                  value="<?php echo e(Carbon\Carbon::parse($info->date_hired)->format('Y-m-d')); ?>" 
                                  required=""
                                >
                              <?php else: ?> 
                                <input 
                                  type="text"
                                  class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                  value="<?php echo e(Carbon\Carbon::parse($info->date_hired)->format('F m, Y')); ?>" 
                                >
                              <?php endif; ?>
                              <label>Date Hired</label>
                              <div class="invalid-feedback">
                                Please fill in the Date Hired
                              </div>
                            </div>                   
                            <div class="form-group col-md-4 col-12">
                              
                              <?php if($user->is_admin == 1): ?>
                                <input 
                                  type="date" 
                                  name="proby_extension"
                                  id="proby_extension"
                                  class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                  value="<?php echo e(Carbon\Carbon::parse($info->proby_extension)->format('Y-m-d')); ?>" 
                                  required=""
                                >
                              <?php else: ?> 
                                <input 
                                  type="text"
                                  class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                  value="<?php echo e(Carbon\Carbon::parse($info->proby_extension)->format('F m, Y')); ?>" 
                                >
                              <?php endif; ?>
                              <label>Probitionary Extension</label>
                              <div class="invalid-feedback">
                                Please fill in the Status
                              </div>
                            </div>

                            <div class="form-group col-md-4 col-12">
                              
                              <?php if($user->is_admin == 1): ?>
                                <input 
                                  type="date" 
                                  name="regular_date"
                                  id="regular_date"
                                  class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                  value="<?php echo e(Carbon\Carbon::parse($info->regular_date)->format('Y-m-d')); ?>" 
                                  required=""
                                >
                              <?php else: ?> 
                                <input 
                                  type="text"
                                  class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                  value="<?php echo e(Carbon\Carbon::parse($info->regular_date)->format('F m, Y')); ?>" 
                                >
                              <?php endif; ?>
                              <label>Regularization Date</label>
                              <div class="invalid-feedback">
                                Please fill in the Status
                              </div>
                            </div>
                          </div>

                          <div class="row">

                            <div class="form-group col-12">
                              <input 
                                type="text" 
                                name="pay_slip_link" 
                                id="pay_slip_link" 
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->pay_slip_link); ?>" 
                                required=""
                              >
                              <label>Payslip</label>
                              <div class="invalid-feedback">
                                Please fill in the Payslip URL
                              </div>
                            </div>

                            <div class="form-group col-md-3 col-12">
                              <input 
                                type="text" 
                                name="employee_id" 
                                id="employee_id" 
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->employee_id); ?>" 
                                required=""
                              >
                              <label>Employee ID no.</label>
                              <div class="invalid-feedback">
                                Please fill in Employee ID no.
                              </div>
                            </div>

                            <div class="form-group col-md-3 col-12">
                              <input 
                                type="text" 
                                name="account_number" 
                                id="account_number" 
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->account_number); ?>" 
                                required=""
                              >
                              <label>Account No.</label>
                              <div class="invalid-feedback">
                                Please fill in the Account No.
                              </div>
                            </div>

                            <div class="form-group col-md-3 col-12">
                              <input 
                                type="text" 
                                name="TIN" 
                                id="TIN" 
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->TIN); ?>" 
                                required=""
                              >
                              <label>TIN No.</label>
                              <div class="invalid-feedback">
                                Please fill in the TIN No.
                              </div>
                            </div>

                            <div class="form-group col-md-3 col-12">
                              <input 
                                type="text" 
                                name="philhealth" 
                                id="philhealth" 
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->philhealth); ?>" 
                                required=""
                              >
                              <label>PhilHealth No.</label>
                              <div class="invalid-feedback">
                                Please fill in the PhilHealth No.
                              </div>
                            </div>

                            <div class="form-group col-md-3 col-12">
                              <input 
                                type="text" 
                                name="sss" 
                                id="sss" 
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->sss); ?>" 
                                required=""
                              >
                              <label>SSS No.</label>
                              <div class="invalid-feedback">
                                Please fill in SSS
                              </div>
                            </div>

                            <div class="form-group col-md-3 col-12">
                              <input 
                                type="text" 
                                name="pagibig" 
                                id="pagibig" 
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->pagibig); ?>" 
                                required=""
                              >
                              <label>Pag-Ibig No.</label>
                              <div class="invalid-feedback">
                                Please fill in Pag-Ibig No.
                              </div>
                            </div>

                            <div class="form-group col-md-3 col-12">
                              <input 
                                type="text" 
                                name="hmo" 
                                id="hmo" 
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->hmo); ?>" 
                                required=""
                              >
                              <label>HMO</label>
                              <div class="invalid-feedback">
                                Please fill in HMO
                              </div>
                            </div>

                            <div class="form-group col-md-3 col-12">
                              <input 
                                type="text" 
                                name="sil_entitlement" 
                                id="sil_entitlement" 
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->sil_entitlement); ?>" 
                                required=""
                              >
                              <label>SIL Entitlement</label>
                              <div class="invalid-feedback">
                                Please fill in sil Entitlement
                              </div>
                            </div>

                            <div class="form-group col-12">
                              <input 
                                type="text" 
                                name="notes" 
                                id="note" 
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->notes); ?>" 
                                required=""
                              >
                              <label>Notes</label>
                              <div class="invalid-feedback">
                                Please Add Some Notes
                              </div>
                            </div>

                          </div>
                      </div>
                    <?php if($user->is_admin == 1 || $info->update_request == 1): ?>
                      <div class="card-header">
                        <h4><i class="fa fa-phone"></i> Employee Contact</h4>
                      </div>
                      <div class="card-body">
                          <div class="row">
                            <div class="form-group col-md-4 col-12">
                              
                              <input 
                                type="text" 
                                name="email" 
                                id="email" 
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->email); ?>" 
                                required=""
                              >
                              <label>Personal Email</label>
                              <div class="invalid-feedback">
                                Please fill in the Personal Email
                              </div>
                            </div>                   
                            <div class="form-group col-md-4 col-12">
                              
                              <input 
                                type="text"
                                name="work_email"
                                id="work_email" 
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->work_email); ?>" 
                                required=""
                              >
                              <label>Company Email</label>
                              <div class="invalid-feedback">
                                Please fill up if no Company Email just put the Personal Email as a reference.
                              </div>
                            </div>
                            <div class="form-group col-md-4 col-12">
                              <input 
                                type="text" 
                                name="cel_no"
                                id="cel_no"
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->cel_no); ?>" 
                                required=""
                              >
                              <label>Mobile No</label>
                              <div class="invalid-feedback">
                                Please fill in the Mobile No
                              </div>
                            </div>
                          </div>

                          <div class="row">
                            
                            <div class="form-group col-12">
                              <input 
                                type="text" 
                                name="address_1"
                                id="address_1"
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->address_1); ?>" 
                                required=""
                              >
                              <label>Current Address</label>
                              <div class="invalid-feedback">
                                Please fill in the Current Address
                              </div>
                            </div>
                          </div>
                      </div>
                      <div class="card-header">
                        <h4><i class="fa fa-warning"></i> Incased of Emergency</h4>
                      </div>
                      <div class="card-body">
                        <div class="row">
                          <div class="form-group col-md-4 col-12">
                              
                              <input 
                                type="text" 
                                name="emergency_name"
                                id="emergency_name"
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->emergency_name); ?>" 
                                required=""
                              >
                              <label>Name 1</label>
                              <div class="invalid-feedback">
                                Please fill in the Incased of Emergency Name 1
                              </div>
                          </div>
                          <div class="form-group col-md-4 col-12">
                              
                              <input 
                                type="text" 
                                name="emergency_relation"
                                id="emergency_relation"
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->emergency_relation); ?>" 
                                required=""
                              >
                              <label>Relation 1</label>
                              <div class="invalid-feedback">
                                Please fill in the Incased of Emergency contact person relation 1
                              </div>
                          </div>
                          <div class="form-group col-md-4 col-12">
                              
                              <input 
                                type="text" 
                                name="emergency_contact"
                                id="emergency_contact"
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->emergency_contact); ?>" 
                                required=""
                              >
                              <label>Contact 1</label>
                              <div class="invalid-feedback">
                                Please fill in the Incased of Emergency Contact No. 1
                              </div>
                          </div>

                          <div class="form-group col-md-4 col-12">
                              
                              <input 
                                type="text" 
                                name="emergency_name2"
                                id="emergency_name2"
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->emergency_name2); ?>" 
                                required=""
                              >
                              <label>Name 2</label>
                              <div class="invalid-feedback">
                                Please fill in the Incased of Emergency Name 2
                              </div>
                          </div>

                          <div class="form-group col-md-4 col-12">
                              
                              <input 
                                type="text" 
                                name="emergency_relation2"
                                id="emergency_relation2"
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->emergency_relation2); ?>" 
                                required=""
                              >
                              <label>Relation 2</label>
                              <div class="invalid-feedback">
                                Please fill in the Incased of Emergency contact person relation 2
                              </div>
                          </div>

                          <div class="form-group col-md-4 col-12">
                              
                              <input 
                                type="text" 
                                name="emergency_contact2"
                                id="emergency_contact2"
                                class="form-control <?php echo e($user->is_admin == 1 ? 'input-disable':''); ?>" 
                                value="<?php echo e($info->emergency_contact2); ?>" 
                                required=""
                              >
                              <label>Contact 2</label>
                              <div class="invalid-feedback">
                                Please fill in the Incased of Emergency Contact No. 2
                              </div>
                          </div>


                        </div>
                      </div>
                      <?php endif; ?>

                    
                    <?php if(  $user->is_admin == 1 || $info->update_request == 1): ?>
                      <div class="card-footer text-right">
                        <button class="btn-button-2">Save Changes</button>
                      </div>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>

        <?php if($user->is_admin == 1): ?>
          <script defer>
              [...document.querySelectorAll(".input-disable")].forEach((element) => {
                  element.classList.toggle('input-able')
              });
          </script>
        <?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel-8-stisla-jetstream-Dec-15\resources\views/components/profile-information.blade.php ENDPATH**/ ?>