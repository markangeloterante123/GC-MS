
<?php $__env->startSection('content'); ?>
     <?php $__env->slot('header_content', null, []); ?> 
        <h4><?php echo e(__('Full data table')); ?></h4>

        <div class="section-header-breadcrumb">
        <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('user.info')); ?>"> User Info</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('user')); ?>">Full View Data</a></div>
        </div>
     <?php $__env->endSlot(); ?>

    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('userfulldata', [])->html();
} elseif ($_instance->childHasBeenRendered('s8u4opX')) {
    $componentId = $_instance->getRenderedChildComponentId('s8u4opX');
    $componentTag = $_instance->getRenderedChildComponentTagName('s8u4opX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('s8u4opX');
} else {
    $response = \Livewire\Livewire::mount('userfulldata', []);
    $html = $response->html();
    $_instance->logRenderedChild('s8u4opX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.docView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-8-stisla-jetstream-Dec-15\resources\views/pages/user/user_full_table.blade.php ENDPATH**/ ?>