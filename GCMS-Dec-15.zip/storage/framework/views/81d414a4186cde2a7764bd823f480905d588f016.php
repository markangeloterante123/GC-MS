<?php
    $user = auth()->user();
?>

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header_content', null, []); ?> 
        <h2><?php echo e(__('Edit Announcement')); ?></h2>

        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('user.info')); ?>">Profile</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('setting.options')); ?>">Setting</a></div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit Announcement')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <section class="section">
        <div class="row mt-sm-4">
            <div class="col-md-6 col-12">
                    <div class="card">
                        <?php if(session('update')): ?>
                            <h6 class="alert alert-success"><?php echo e(session('update')); ?></h6>
                        <?php endif; ?>
                        <div class="card-header">
                            <h4><i class="fa fa-edit"></i> Edit Memo</h4>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(url('/memo/update/'.$data->id)); ?>" method="post"  class="needs-validation" novalidate="">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>
                                <div class="card-body"> 
                                    <div class="row">

                                        <div class="form-group col-12">
                                            <input 
                                                type="text" 
                                                name="memo_title"
                                                id="memo_title"
                                                class="form-control" 
                                                value="<?php echo e($data->memo_title); ?>"
                                                required=""
                                            >
                                            <label>Title</label>
                                            <div class="invalid-feedback">
                                                Please fill in the Title
                                            </div>
                                        </div>
                                        <label class="label-comment">No of content</label>
                                        <div class="form-group col-12">
                                            <textarea name="content" class="form-control" id="content-edit-memo" cols="30" rows="10" required="">
                                                <?php echo e($data->content); ?>

                                            </textarea>
                                            
                                            <div class="invalid-feedback">
                                                Please fill in content
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="card-footer text-right">
                                    <button class="btn-button-2">Save Changes</button>
                                </div>
                            </form>
                        </div>
                    </div>
            </div>

            <?php if($user->is_admin == 1): ?>
                <div class="col-md-6 col-12">
                    <div class="card">
                            <?php if(session('status')): ?>
                                <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
                            <?php endif; ?>
                        <div class="card-header">
                            <h4><i class="fas fa-plus"></i> Post Memo</h4>
                        </div>

                        <form action="<?php echo e(url('/memo/add/'.$user->name)); ?>" method="post"  class="needs-validation" novalidate="">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="card-body"> 
                                <div class="row">

                                    <div class="form-group col-12">
                                        <input 
                                            type="text" 
                                            name="memo_title"
                                            id="memo_title"
                                            class="form-control" 
                                            required=""
                                        >
                                        <label>Title</label>
                                        <div class="invalid-feedback">
                                            Please fill in the Title
                                        </div>
                                    </div>
                                    <label class="label-comment">No of content</label>
                                    <div class="form-group col-12">
                                        <textarea name="content" class="form-control" id="content-edit-memo2" cols="30" rows="10" required="">
                                        </textarea>
                                        
                                        <div class="invalid-feedback">
                                            Please fill in content
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="card-footer text-right">
                                <button class="btn-button-2">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
            
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel-8-stisla-jetstream-Dec-15\resources\views/pages/memo/memo_edit.blade.php ENDPATH**/ ?>