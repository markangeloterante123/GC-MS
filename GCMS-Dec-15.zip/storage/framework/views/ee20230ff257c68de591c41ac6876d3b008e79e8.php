<?php
    $user = auth()->user();
?>

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header_content', null, []); ?> 
        <h2><?php echo e(__('Send Reprimand')); ?></h2>

        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('user.info')); ?>">Profile</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('setting.options')); ?>">Setting</a></div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Reprimand')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <section class="section">
        <div class="row mt-sm-4">

                <div class="<?php echo e($user->is_admin == 1 ? 'col-md-6':'col-12'); ?> col-12">
                    <div class="row">
                        <!-- first col user-information -->
                        <div class="col-12">
                            <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card profile-widget">
                                <div class="profile-widget-header">
                                    <img src="<?php echo e(asset($info->profile_photo_url)); ?>" alt="<?php echo e($info->name); ?>" style="width:130px; height:130px; border:3px solid #fff;" class="rounded-circle profile-widget-picture">
                                    <div class="profile-widget-items">
                                    <div class="profile-widget-item">
                                        <div class="profile-widget-item-label title-label">Date Hired</div>
                                        <div class="profile-widget-item-value title-value"><?php echo e(\Carbon\Carbon::parse($info->date_hired)->format('j F, Y')); ?></div>
                                    </div>
                                    <div class="profile-widget-item">
                                        <div class="profile-widget-item-label title-label">Status</div>
                                        <div class="profile-widget-item-value title-value">
                                            <?php echo e($info->employement_status); ?>

                                        </div>
                                    </div>
                                    </div>
                                </div>
                            <div class="profile-widget-description">
                                <div class="profile-widget-name title-value">
                                    Name:
                                    <div class="text-muted d-inline font-weight-normal ">
                                        <div class="slash"></div> 
                                        <?php echo e($info->name); ?>

                                    </div>
                                </div>
                                <div class="profile-widget-name title-value">
                                    Company Email:
                                    <div class="text-muted d-inline font-weight-normal ">
                                        <div class="slash"></div> 
                                        <?php echo e($info->work_email); ?>

                                    </div>
                                </div>
                                
                                <div class="profile-info">
                                    <h2>Name: <?php echo e($info->name); ?></h2>
                                    <h3>Company Email: <?php echo e($info->work_email); ?></h3>
                                    <h3>Status: <?php echo e($info->employement_status); ?></h3>
                                    </div>
                                    <?php $__currentLoopData = $opt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <?php if($op->options == $info->designation): ?>
                                        <div class="user-information">
                                        <h2><?php echo e($info->designation); ?></h2>
                                        <p><?php echo e($op->description); ?></p>
                                        </div>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- end col -->
                        <!-- 2nd col -->
                        

                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4><i class="fas fa-times-circle"></i> Reprimand Records</h4>
                                </div>
                                <div class="card-body">
                                <?php $__currentLoopData = $reptRecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $records): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!-- accordion start here -->
                                        <?php if($records->status == "Require Explanation"): ?>
                                            <span class="btn btn-danger btn-notification"> <i class="fa fa-times"></i> <?php echo e($records->status); ?></span>
                                        <?php elseif($records->status == "Answered"): ?>
                                            <?php if($user->is_admin == 1): ?>
                                                <span class="btn btn-info btn-notification"> <i class="fa fa-calendar"></i> <?php echo e($records->status); ?></span>
                                            <?php else: ?>
                                                <span class="btn btn-warning btn-notification"> <i class="fa fa-calendar"></i> Pending Cased</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <div class="accordion md-accordion" id="accordionEx<?php echo e($records->id); ?>" role="tablist" aria-multiselectable="true">
                                            <div class="card">
                                                    <div class="card-header" role="tab" id="headingTree">
                                                        <a data-toggle="collapse" data-parent="#accordionEx<?php echo e($records->id); ?>" href="#collapseRec<?php echo e($records->id); ?>" aria-expanded="true"
                                                                    aria-controls="collapseRec<?php echo e($records->id); ?>">
                                                        <h3 class="mb-0 " style="color:#02b075;">
                                                            <?php echo e($records->type_of_offense); ?> <i class="fas fa-angle-down rotate-icon"></i>
                                                        </h3>
                                                        </a>
                                                    </div>
                                                    <div id="collapseRec<?php echo e($records->id); ?>" class="collapse" role="tabpanel" aria-labelledby="headingTree"
                                                                data-parent="#accordionEx<?php echo e($records->id); ?>">
                                                        <div class="card-body">
                                                            <div class="row">
                                                                <div class="accordion-wrapper">
                                                                    <button class="toggles" >
                                                                        View Details  <i class="fas fa-plus icon"></i>
                                                                    </button>
                                                                <div class="content">
                                                                    <h3>Type of Offense: <span><?php echo e($records->type_of_offense); ?></span></h3>
                                                                    <h3>Date Issued: <span><?php echo e(\Carbon\carbon::parse( $info->date_given )->format('F, j  Y')); ?></span></h3>
                                                                    <h3>No. of offense: <span><?php echo e($records->no_of_offense); ?></span></h3>
                                                                    <h3>Issued by: <span><?php echo e($records->issue_by); ?></span> </h3>
                                                                    
                                                                    <h2 style="padding-top:30px;">Details</h2>
                                                                    <p> Click here to view the detail of the report <a href="<?php echo e($records->detail_reports); ?>" target="_blank">View Detail</a></p>
                                                                    
                                                                    <?php if($user->is_admin == 0): ?>
                                                                        <?php if(!$records->written_explanation && !$records->actions_taken): ?>
                                                                            <h2 style="padding-top:30px;">Write written explanation</h2>
                                                                            <form action="<?php echo e(url('send/user/explination/'.$records->id)); ?>" method="post" class="needs-validation" novalidate="">
                                                                                <?php echo csrf_field(); ?>
                                                                                <?php echo method_field('PUT'); ?>
                                                                                <div class="row">
                                                                                    <div class="form-group col-12">
                                                                                        <input type="text" id="written_explanation" name="written_explanation" class="form-control" required="">
                                                                                        <label for="">Explanation letter ( URL Documents )</label>
                                                                                        <div class="invalid-feedback">
                                                                                            Please fill in the reprimand type
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="card-footer">
                                                                                        <button class="btn-button-2">Send explanation letter</button>
                                                                                    </div>
                                                                                </div>
                                                                            </form>
                                                                        <?php else: ?>
                                                                        <h2 style="padding:30px 0px 30px 0px;">Explanation letter: <a href="<?php echo e($records->written_explanation); ?>" target="_blank"> View my explanation</a></h2>
                                                                        <?php endif; ?>
                                                                    <?php else: ?>
                                                                        <?php if(!$records->actions_taken): ?>
                                                                            <form action="<?php echo e(url('send/user/actions/'.$records->id)); ?>" method="post" class="needs-validation" novalidate="">
                                                                                <?php echo csrf_field(); ?>
                                                                                <?php echo method_field('PUT'); ?>
                                                                                <div class="row">
                                                                                <label class="label-comment">Disciplinary action</label>
                                                                                    <div class="form-group col-12">
                                                                                        <textarea name="actions_taken" id="actions_taken-send" class="form-control" cols="30" rows="10" required=""></textarea>
                                                                                        <div class="invalid-feedback">
                                                                                            Please fill in the Disciplinary action
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="card-footer">
                                                                                        <button class="btn-button-2">Send</button>
                                                                                    </div>
                                                                                </div>
                                                                            </form>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                    <?php if($records->actions_taken): ?>
                                                                    <h2 style="padding-bottom:10px">Sanctions</h2>
                                                                    <p style="padding-bottom:30px"><?php echo $records->actions_taken; ?></p>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <!-- accordion end -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        
                        <!-- end col -->
                    </div>
                </div>
            
                <div class="col-md-6 col-12">
                    <div class="row">
                        <?php if($user->is_admin == 1): ?>
                            <div class="col-12">
                                <div class="card">
                                    <?php if(session('status')): ?>
                                        <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
                                    <?php endif; ?>
                                    <div class="card-header">
                                        <h4>Send Reprimand</h4>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?php echo e(url('/send/user/reprimand/'.$userId)); ?>" method="post" class="needs-validation" novalidate="">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                            <div class="row">  
                                                <input type="hidden" id="issue_by" name="issue_by" value="<?php echo e($user->name); ?>" > 
                                                <div class="form-group col-md-6 col-12">
                                                    <select name="type_of_offense" id="type_of_offense" class="form-control" required="">
                                                        <?php $__currentLoopData = $rept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($info->type_of_offense); ?>"><?php echo e($info->type_of_offense); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                        
                                                    </select>
                                                    <label>Type of Reprimand</label>

                                                    <div class="invalid-feedback">
                                                        Please fill in the reprimand type
                                                    </div>
                                                </div>

                                                <div class="form-group col-md-3 col-12">
                                                    <input type="text" name="no_of_offense" id="no_of_offense" class="form-control" required="">
                                                    <label>No. of Offense</label>

                                                    <div class="invalid-feedback">
                                                        Please fill in the reprimand type
                                                    </div>
                                                </div>

                                                <div class="form-group col-md-3 col-12">
                                                    <input type="date" name="date_given" id="date_given" class="form-control" required="">
                                                    <label class="label-2">Date Send</label>
                                                    <div class="invalid-feedback">
                                                        Please fill the fields
                                                    </div>
                                                </div>

                                                <div class="form-group col-12">
                                                    <input type="text" id="detail_reports" name="detail_reports" class="form-control" required="">
                                                    <label class="">Offense Detail Report ( URL Documents )</label>
                                                    <div class="invalid-feedback">
                                                        Please fill the fields
                                                    </div>
                                                </div>
                                                <div class="card-footer text-right">
                                                    <button class="btn-button-2">Send</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                

               

                

        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel-8-stisla-jetstream-Dec-15\resources\views/pages/reprimand/reprimand_user.blade.php ENDPATH**/ ?>