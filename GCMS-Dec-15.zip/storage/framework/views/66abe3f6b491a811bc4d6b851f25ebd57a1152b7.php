<?php
    $user = auth()->user();
?>

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header_content', null, []); ?> 
        <h2><?php echo e(__('System Documentation')); ?></h2>

        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('user.info')); ?>">Profile</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('setting.options')); ?>">Documentation</a></div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('System Documentation')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <section class="section">
        <div class="row mt-sm-4">
           <div class="col-md-6 col-12">
             
                   <div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
                        <div class="card">
                            <div class="card-header" role="tab" id="headingTree">
                                <a data-toggle="collapse" data-parent="#accordionEx" href="#collapseRec" aria-expanded="true"
                                                        aria-controls="collapseRec">
                                <h3 class="mb-0 " style="color:#02b075;">
                                Create Account  <i class="fas fa-angle-down rotate-icon"></i>
                                </h3>
                                </a>
                                
                            </div>
                            <div id="collapseRec" class="collapse" role="tabpanel" aria-labelledby="headingTree"
                                                    data-parent="#accordionEx">
                                <div class="card-body">
                                    <p>GoCrayons Management System (GCMS) has 3 ways to create an account first is Users manually register on the system landing page.</p>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <!-- 1st -->
                                        <div class="accordion-wrapper">
                                                <button class="toggles" >
                                                    Manual Registration <i class="fas fa-plus icon"></i>
                                                </button>
                                            <div class="content">          
                                                <h2 style="padding-top:30px;">Details</h2>
                                                <p>Go to the landing page and click the Register Now fill up the registration form using your company Email. </p>
                                                <img src="<?php echo e(asset('img/faq-registration/registration_1.PNG')); ?>" alt="registration">
                                            </div>
                                        </div>
                                        <!-- 2nd -->
                                        <div class="accordion-wrapper">
                                                <button class="toggles" >
                                                    Admin Create User Account <i class="fas fa-plus icon"></i>
                                                </button>
                                            <div class="content">          
                                                <h2 style="padding-top:30px;">Details</h2>
                                                <p>Go to the landing page and click the Register Now fill up the registration form using your company Email. </p>
                                                <img src="<?php echo e(asset('img/faq-registration/registration_1.PNG')); ?>" alt="registration">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
               
           </div>
           <div class="col-md-6 col-12">
               
           </div>
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel-8-stisla-jetstream-Dec-15\resources\views/pages/documentation/faq.blade.php ENDPATH**/ ?>