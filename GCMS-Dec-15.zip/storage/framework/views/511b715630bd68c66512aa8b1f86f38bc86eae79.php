<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\laravel-8-stisla-jetstream-Dec-15\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>