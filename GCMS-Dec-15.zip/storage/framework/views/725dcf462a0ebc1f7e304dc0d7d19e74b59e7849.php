<?php
    $user = auth()->user();
?>

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header_content', null, []); ?> 
        <h2><?php echo e(__('Code of Conducts')); ?></h2>

        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('user.info')); ?>">Profile</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('setting.options')); ?>">Setting</a></div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Code of Conducts')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <section class="section">
        <div class="row mt-sm-4">

            <div class="<?php echo e($user->is_admin == 1 ? 'col-md-7':'col-12'); ?> col-12">
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fa fa-info-circle"></i> Code of Conducts Informations </h4>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- start here -->
                                <div class="accordion md-accordion" id="accordionEx<?php echo e($info->id); ?>" role="tablist" aria-multiselectable="true">
                                    <div class="card">
                                        <div class="card-header" role="tab" id="headingTree">
                                            <a data-toggle="collapse" data-parent="#accordionEx<?php echo e($info->id); ?>" href="#collapseRec<?php echo e($info->id); ?>" aria-expanded="true"
                                                        aria-controls="collapseRec<?php echo e($info->id); ?>">
                                            <h3 class="mb-0 " style="color:#02b075;">
                                            <?php echo e($info->type_of_offense); ?><i class="fas fa-angle-down rotate-icon"></i>
                                            </h3>
                                            </a>
                                        </div>
                                        <div id="collapseRec<?php echo e($info->id); ?>" class="collapse" role="tabpanel" aria-labelledby="headingTree"
                                                    data-parent="#accordionEx<?php echo e($info->id); ?>">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="accordion-wrapper">
                                                        <button class="toggles" >
                                                            View Details  <i class="fas fa-plus icon"></i>
                                                        </button>
                                                    <div class="content">
                                                        <h3>Date Issued: <span><?php echo e(\Carbon\carbon::parse( $info->created_at )->format('F, j  Y')); ?></span></h3>
                                                        <h3>Author By: <span><?php echo e($info->author_by); ?></span> </h3>
                                                        
                                                        <h2 style="padding-top:30px;">Details</h2>
                                                        <?php echo $info->details; ?>


                                                        <p><?php echo $info->no_of_offense; ?></p>        

                                                    </div>
                                                </div>
                                            </div>
                                            <?php if($user->is_admin == 1): ?>
                                                <div class="card-footer footer-display text-right">
                                                    <div class="row">
                                                        <div class="col-6">
                                                            <form action="<?php echo e(url('/reprimand/delete/'.$info->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button class="btn-button-2">Remove</button>
                                                            </form>
                                                        </div>
                                                        <div class="col-6 btn-pad">
                                                            <a href="<?php echo e(url('/reprimand/edit/'.$info->id)); ?>" class="btn-button-2 ">Edit</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <!-- end here -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </div>
                </div>
            </div>
    

            <?php if($user->is_admin == 1): ?>
                <div class="col-md-5 col-12">
                    <div class="card">
                            <?php if(session('status')): ?>
                                <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
                            <?php endif; ?>
                        <div class="card-header">
                            <h4><i class="fas fa-plus"></i> Add code of conducts</h4>
                        </div>

                        <form action="<?php echo e(url('/reprimand/add/'.$user->name)); ?>" method="post"  class="needs-validation" novalidate="">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="card-body"> 
                                <div class="row">

                                    <div class="form-group col-12">
                                        <input 
                                            type="text" 
                                            name="type_of_offense"
                                            id="type_of_offense"
                                            class="form-control" 
                                            required=""
                                        >
                                        <label>Type of Offense</label>
                                        <div class="invalid-feedback">
                                            Please fill in the Title
                                        </div>
                                    </div>

                                    <label class="label-comment">Offense Detail</label>
                                    <div class="form-group col-12">
                                        <textarea name="details" class="form-control" id="details_reprimand" cols="30" rows="10" required="">
                                        </textarea>
                                        <div class="invalid-feedback">
                                            Please fill in the Offense details
                                        </div>
                                    </div>
                                    
                                    <label class="label-comment">No of Offense regulations</label>
                                    <div class="form-group col-12">
                                        <textarea name="no_of_offense" class="form-control" id="no_of_offense_reprimand" cols="30" rows="10" required="">
                                        </textarea>
                                        <div class="invalid-feedback">
                                            Please fill in no of Offense
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="card-footer text-right">
                                <button class="btn-button-2">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel-8-stisla-jetstream-Dec-15\resources\views/pages/reprimand/reprimand.blade.php ENDPATH**/ ?>